"""Free public inputs. Missing/unsupported values always remain unknown.
Open-Meteo model metadata is NOT the exact issuance timestamp of a stitched series.
MOE point forecasts are a nearby-site proxy, never an in-park measurement.
"""
import csv, io, math, time
from datetime import datetime,timedelta,timezone
from .sources import get,JST
MODEL='icon_global'
META_URL='https://api.open-meteo.com/data/dwd_icon/static/meta.json'
WBGT_URL='https://www.wbgt.env.go.jp/prev15WG/dl/yohou_44136.csv'
WBGT_STATION='44136'
WARNING_URL='https://www.jma.go.jp/bosai/warning/data/warning/120000.json'
NOWCAST_URL='https://www.jma.go.jp/bosai/jmatile/data/nowc/targetTimes_N2.json'
_cache={}

def cached(key,ttl,loader):
    entry=_cache.get(key)
    if entry and time.monotonic()-entry[0]<ttl:
        if isinstance(entry[1],Exception):raise RuntimeError('cached_source_failure')
        return entry[1]
    try:v=loader()
    except Exception:
        _cache[key]=(time.monotonic(),RuntimeError('source_unavailable'));raise
    _cache[key]=(time.monotonic(),v);return v

def json_source(url,ttl=600):return cached(url,ttl,lambda:get(url).json())

def metadata_freshness(meta,now):
    try:
        init=datetime.fromtimestamp(meta['last_run_initialisation_time'],timezone.utc)
        available=datetime.fromtimestamp(meta['last_run_availability_time'],timezone.utc)
        interval=meta['update_interval_seconds']
        if isinstance(interval,bool) or not isinstance(interval,(int,float)) or not 3600<=interval<=43200:raise ValueError()
        age=(now-available).total_seconds();run_age=(now-init).total_seconds()
        # Ten minutes for cross-server propagation; conservative missed-run limit.
        fresh=600<=age<=interval+7200 and 0<=run_age<=interval+21600 and init<=available<=now
        return dict(source_age_verified=fresh,latest_model_initialisation_at=init.isoformat(),
                    model_available_at=available.isoformat(),update_interval_seconds=interval,
                    freshness_method='explicit_model_metadata_with_10min_propagation_margin')
    except (KeyError,TypeError,ValueError,OverflowError,OSError):
        return dict(source_age_verified=False,freshness_method='metadata_invalid')

def parse_wbgt_csv(text,now):
    rows=list(csv.reader(io.StringIO(text.lstrip('\ufeff'))))
    if len(rows)<2 or len(rows[0])<3 or rows[0][:2]!=['','']:raise ValueError('wbgt_schema')
    row=next((r for r in rows[1:] if r and r[0].strip()==WBGT_STATION),None)
    if row is None or len(row)!=len(rows[0]):raise ValueError('wbgt_station_or_columns')
    issued=datetime.strptime(row[1].strip(),'%Y/%m/%d %H:%M').replace(tzinfo=JST)
    points=[]
    for key,value in zip(rows[0][2:],row[2:]):
        key=key.strip()
        if len(key)!=10 or not key.isdigit():raise ValueError('wbgt_target_time')
        hour=int(key[8:]);base=datetime.strptime(key[:8],'%Y%m%d').replace(tzinfo=JST)
        if hour==24:target=base+timedelta(days=1)
        elif hour in (3,6,9,12,15,18,21):target=base+timedelta(hours=hour)
        else:raise ValueError('wbgt_target_hour')
        value=value.strip();v=None
        if value:
            v=int(value)/10
            if not math.isfinite(v) or not -30<=v<=60 or not v.is_integer():raise ValueError('wbgt_forecast_value')
            v=int(v)
        points.append(dict(target_at=target.isoformat(),value=v))
    if any(a['target_at']>=b['target_at'] for a,b in zip(points,points[1:])):raise ValueError('wbgt_target_order')
    return dict(provider='環境省',source=WBGT_URL,station=WBGT_STATION,station_name='江戸川臨海',
        kind='forecast',issued_at=issued.isoformat(),retrieved_at=now.isoformat(),points=points,
        fresh=timedelta(0)<=now-issued<=timedelta(minutes=90),in_park=False)

def wbgt_proxy(series,start,end,now):
    issued=datetime.fromisoformat(series['issued_at'])
    if not timedelta(0)<=now-issued<=timedelta(minutes=90):return None
    pts=[(datetime.fromisoformat(p['target_at']),p['value']) for p in series['points']]
    left=[p for p in pts if p[0]<=start];right=[p for p in pts if p[0]>=end]
    if not left or not right:return None
    low,high=left[-1][0],right[0][0]
    selected=[p for p in pts if low<=p[0]<=high]
    if any(v is None for _,v in selected):return None
    if any(b[0]-a[0]>timedelta(hours=3) for a,b in zip(selected,selected[1:])):return None
    return dict(value=max(v for _,v in selected),method='adjacent_3hour_max_proxy',
        source=series['source'],station=series['station'],station_name=series['station_name'],
        issued_at=series['issued_at'],retrieved_at=series['retrieved_at'],in_park=False,
        sampled_times=[t.isoformat() for t,_ in selected])

def parse_warning(data,now):
    # Retain exact city; do not infer no-lightning from absence of an advisory.
    report=datetime.fromisoformat(data['reportDatetime'])
    if not timedelta(0)<=now-report<=timedelta(hours=24):return dict(status='unknown',reason='warning_report_stale')
    city=next((a for t in data.get('areaTypes',[]) for a in t.get('areas',[]) if a.get('code')=='1222700'),None)
    if city is None:return dict(status='unknown',reason='city_not_found')
    risk=any(w.get('code')=='14' and w.get('status') in ('発表','継続') for w in city.get('warnings',[]))
    return dict(status='risk' if risk else 'unknown',reason='浦安市に雷注意報' if risk else '雷注意報の有無だけでは雷なしを確認できない',
                provider='気象庁',source=WARNING_URL,issued_at=report.isoformat(),retrieved_at=now.isoformat())

def parse_nowcast_timeline(rows,now):
    valid=[]
    for r in rows:
        if 'hrpns' not in r.get('elements',[]):continue
        base=datetime.strptime(r['basetime'],'%Y%m%d%H%M%S').replace(tzinfo=timezone.utc)
        target=datetime.strptime(r['validtime'],'%Y%m%d%H%M%S').replace(tzinfo=timezone.utc)
        if timedelta(0)<=now-base<=timedelta(minutes=15) and base<=target<=base+timedelta(hours=1):
            valid.append((base,target))
    return dict(provider='気象庁',source=NOWCAST_URL,retrieved_at=now.isoformat(),status='timeline_available' if valid else 'stale_or_missing',
                latest_basetime=max((b for b,t in valid),default=None).isoformat() if valid else None,
                horizon=max((t for b,t in valid),default=None).isoformat() if valid else None,
                radar='unknown',reason='配信時刻一覧だけでは地点の雨量や雨雲接近を判定できない')

def fetch_free_extras(now):
    result={}
    try:
        text,fetched=cached(WBGT_URL,3600,lambda:(get(WBGT_URL).text,now.isoformat()))
        result['wbgt_series']=parse_wbgt_csv(text,now)
        result['wbgt_series']['retrieved_at']=fetched
    except Exception:result['wbgt_error']='unavailable_or_invalid'
    try:result['lightning_advisory']=parse_warning(json_source(WARNING_URL,600),now)
    except Exception:result['lightning_advisory']=dict(status='unknown',reason='warning_fetch_failed')
    try:result['nowcast_timeline']=parse_nowcast_timeline(json_source(NOWCAST_URL,300),now)
    except Exception:result['nowcast_timeline']=dict(radar='unknown',status='unavailable',reason='timeline_fetch_failed')
    return result

def factors(w):
    """Separate partial, experience-based factor notes from the overall probability."""
    result={}
    def finite(k):return isinstance(w.get(k),(float,int)) and not isinstance(w.get(k),bool) and math.isfinite(w[k])
    if finite('gust'):
        result['wind']='突風13m/s以上・経験則上の警戒' if w['gust']>=13 else '突風12m/s以上・注意' if w['gust']>=12 else '取得した予測では突風12m/s未満'
    else:result['wind']='突風データ未取得'
    result['rain']=('時間降水量5mm以上・注意' if w['rain']>=5 else '時間降水量の予測あり') if finite('rain') else '降水量未取得'
    result['lightning']='雷リスク情報あり' if w.get('lightning')=='risk' else '雷の確認不足' if w.get('lightning')!='clear' else '雷評価データあり'
    result['radar']='雨雲接近の確認不足' if w.get('radar')=='unknown' else w.get('radar','未取得')
    result['heat']='WBGT未取得' if not finite('wbgt') else '近隣地点WBGT予測（パーク内実測ではない）'
    result['freshness']='モデル更新時刻を確認' if w.get('source_age_verified') else 'モデル更新時刻未確認'
    return result
