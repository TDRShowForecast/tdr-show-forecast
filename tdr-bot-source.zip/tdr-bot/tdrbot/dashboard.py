"""Read-only operational dashboard. Bind through loopback in Compose; SSH tunnel to view."""
import html,json
from http.server import HTTPServer,BaseHTTPRequestHandler
from sqlalchemy import select
from .db import connect,State,Post,Incident,Prediction,Result
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path!='/':self.send_error(404);return
        with connect()() as s:
            state={r.key:r.value for r in s.scalars(select(State))}
            posts=[dict(time=r.created_at,status=r.status,text=r.text,error=r.error) for r in s.scalars(select(Post).order_by(Post.created_at.desc()).limit(20))]
            incidents=[dict(time=r.created_at,event=r.code,notified=r.notified) for r in s.scalars(select(Incident).order_by(Incident.created_at.desc()).limit(20))]
            data=dict(state=state,posts=posts,incidents=incidents)
        out=('<!doctype html><html lang="ja"><meta charset="utf-8"><title>TDR Bot 管理</title><style>body{font:16px system-ui;margin:40px;background:#f4f7fa;color:#123}pre{white-space:pre-wrap;background:white;padding:24px;border-radius:12px}</style><h1>TDR Bot 稼働状況</h1><p>非公式。送信停止・再開は管理CLIから操作してください。</p><pre>'+html.escape(json.dumps(data,ensure_ascii=False,indent=2))+'</pre></html>').encode()
        self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(out)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(out)
    def log_message(self,*args):pass
if __name__=='__main__':
    from .config import load_env
    load_env()
    HTTPServer(('127.0.0.1' if __import__('os').getenv('LOCAL_MAC')=='true' else '0.0.0.0',8080),Handler).serve_forever()
