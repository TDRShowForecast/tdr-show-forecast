import argparse, hashlib, json, os, time, uuid
from datetime import datetime,timedelta
from pathlib import Path
import requests
from sqlalchemy import select
from .db import connect,Show,Performance,Weather,Prediction,Result,Post,State,Incident
from .sources import JST,fetch_schedule,fetch_weather,at_performance
from .model import predict,VERSION
from .posting import publish,render

def uid():return str(uuid.uuid4())
def phase_for(start,now):
    local=now.astimezone(JST);start=start.astimezone(JST)
    if start.date()==local.date()+timedelta(days=1) and local.hour==20:return '前日'
    if start.date()==local.date() and local.hour==7:return '朝'
    delta=(start-now).total_seconds()/60
    if 0<delta<=120:
        if delta<=10:return '10分前'
        if delta<=30:return '30分前'
        if delta<=60:return '1時間前'
        return '重点監視'
    return None

def alert(session,code,now):
    # Debounced notification, only sanitized event codes; no API payloads or secrets.
    key='alert:'+code;old=session.get(State,key)
    if old and now-datetime.fromisoformat(old.value)<timedelta(hours=1):return
    event=Incident(id=uid(),created_at=now.isoformat(),code=code,notified=False)
    session.add(event);session.merge(State(key=key,value=now.isoformat()));session.commit()
    if os.getenv('ADMIN_WEBHOOK'):
        try:
            r=requests.post(os.environ['ADMIN_WEBHOOK'],json={'text':'TDR Bot: '+code},timeout=10)
            r.raise_for_status();event.notified=True;session.commit()
        except Exception:print(json.dumps({'event':'notification_failed','code':code}),flush=True)
    print(json.dumps({'event':code}),flush=True)

def tick(session,now,profiles):
    # Only one worker: advisory lock across sessions/hosts when PostgreSQL is used.
    from sqlalchemy import text
    pg=session.bind.dialect.name=='postgresql'
    if not pg:
        _tick(session,now,profiles);return
    # Hold a dedicated checked-out session connection through all ORM commits.
    # Session advisory locks are unsuitable for a transaction-mode pooler.
    with session.bind.connect() as guard:
        acquired=guard.execute(text('SELECT pg_try_advisory_lock(780113)')).scalar()
        guard.commit()
        if not acquired:return
        try:_tick(session,now,profiles)
        finally:
            guard.execute(text('SELECT pg_advisory_unlock(780113)'))
            guard.commit()

def _tick(session,now,profiles):
    if os.getenv('SCHEDULE_TERMS_REVIEWED')!='true':
        session.merge(State(key='heartbeat',value=now.isoformat()));session.commit()
        alert(session,'schedule_terms_not_reviewed',now);return
    today=now.astimezone(JST).date();fresh=set()
    for park in ('tdl','tds'):
        for day in (today,today+timedelta(days=1)):
            key=f'schedule:{park}:{day}';old=session.get(State,key)
            if old and now-datetime.fromisoformat(old.value)<timedelta(minutes=30):fresh.add((park,str(day)));continue
            try:
                rows,unknown=fetch_schedule(park,str(day),profiles)
                session.merge(State(key=f'unknown:{park}:{day}',value=json.dumps(unknown,ensure_ascii=False)))
                if unknown:alert(session,'unclassified_shows_'+park,now)
                existing=session.scalars(select(Performance).join(Show,Show.id==Performance.show_id).where(Show.park==park,Performance.starts_at.like(str(day)+'%'))).all()
                for p in existing:p.active=False
                for row in rows:
                    session.merge(Show(id=row['show_id'],name=row['name'],park=park,kind=row['kind'],config=row['config'],source=row['source']))
                    session.merge(Performance(id=row['id'],show_id=row['show_id'],starts_at=row['starts_at'],fetched_at=row.get('fetched_at',now.isoformat()),active=True,source=row['source']))
                session.merge(State(key=key,value=now.isoformat()));session.commit();fresh.add((park,str(day)))
            except Exception:
                session.rollback();alert(session,'schedule_fetch_failed_'+park,now)
    supplements=json.loads(Path(os.environ['SUPPLEMENT_FILE']).read_text()) if os.getenv('SUPPLEMENT_FILE') else None
    raw_by_park={}
    extras=None
    for performance in session.scalars(select(Performance).where(Performance.active==True)).all():
        start=datetime.fromisoformat(performance.starts_at)
        if start<=now:
            if not session.get(Result,performance.id):session.add(Result(id=performance.id,performance_id=performance.id,outcome='unconfirmed'))
            continue
        phase=phase_for(start,now)
        if phase is None:continue
        show=session.get(Show,performance.show_id)
        if (show.park,str(start.date())) not in fresh:continue
        if show.park not in raw_by_park:
            try:
                raw=fetch_weather(show.park,now);raw['park']=show.park
                if extras is None:
                    from .free_weather import fetch_free_extras
                    extras=fetch_free_extras(now)
                raw['extras']=extras
                raw_by_park[show.park]=raw
            except Exception:
                raw_by_park[show.park]=None
                alert(session,'weather_fetch_failed_'+show.park,now);continue
        if raw_by_park[show.park] is None:continue
        try:
            w=at_performance(raw_by_park[show.park],start,show.config.get('duration_minutes',40),now,supplements)
            wid=uid();session.add(Weather(id=wid,retrieved_at=now.isoformat(),target=start.isoformat(),payload=w))
            pred=predict(show.kind,w,now,profile_verified=show.config.get('profile_verified',False) and show.config.get('classification_verified',True))
            history=session.scalars(select(Prediction).where(Prediction.performance_id==performance.id).order_by(Prediction.created_at.desc())).first()
            session.add(Prediction(id=uid(),performance_id=performance.id,created_at=now.isoformat(),weather_id=wid,phase=phase,model=VERSION,payload=pred))
            fingerprint=hashlib.sha256(json.dumps({'p':pred['probabilities'],'reasons':pred['reasons'],'rank':pred['rank']},ensure_ascii=False,sort_keys=True).encode()).hexdigest()
            major=False
            if history:
                oldp=history.payload
                major=oldp['status']!=pred['status'] or oldp['rank']!=pred['rank']
                if oldp['probabilities'] and pred['probabilities']:
                    major=major or abs(oldp['probabilities']['cancelled']-pred['probabilities']['cancelled'])>=20
            should=phase in ('前日','朝','30分前') or (major and phase in ('10分前','1時間前','重点監視'))
            if should:
                # Max one routine post per phase; irregular posts keyed by fingerprint, cooldown below.
                pid=performance.id+':'+phase+((':'+fingerprint) if phase not in ('前日','朝','30分前') else '')
                last=session.scalars(select(Post).where(Post.performance_id==performance.id,Post.status.in_(['sent','unknown','sending'])).order_by(Post.created_at.desc())).first()
                if major and last and now-datetime.fromisoformat(last.created_at)<timedelta(minutes=20):continue
                status=publish(session,pid,performance.id,phase,render(show,start,pred,w,phase),fingerprint,now)
                if status in ('failed','unknown','daily_limit','approval_required'):alert(session,'posting_'+status,now)
        except Exception:
            session.rollback();alert(session,'prediction_pipeline_failed',now)
    session.merge(State(key='heartbeat',value=now.isoformat()));session.commit()

def main():
    from .config import load_env
    load_env()
    p=argparse.ArgumentParser();p.add_argument('command',choices=['once','run','pause','resume','status','reconcile'])
    p.add_argument('--post-id');p.add_argument('--x-id');p.add_argument('--not-sent',action='store_true')
    args=p.parse_args();factory=connect()
    with factory() as s:
        if args.command in ('pause','resume'):
            s.merge(State(key='paused',value=str(args.command=='pause').lower()));s.commit();return
        if args.command=='status':
            for row in s.scalars(select(State)): print(row.key,row.value)
            return
        if args.command=='reconcile':
            row=s.get(Post,args.post_id)
            if row is None or row.status not in ('sending','unknown'):raise ValueError('post is not uncertain')
            if bool(args.x_id)==bool(args.not_sent):raise ValueError('choose --x-id or --not-sent after checking X')
            row.status='sent' if args.x_id else 'confirmed_not_sent';row.x_id=args.x_id;s.commit();return
    profiles=json.loads(Path(os.getenv('PROFILES_FILE','profiles.json')).read_text())
    while True:
        try:
            with factory() as s:tick(s,datetime.now(JST),profiles)
        except Exception:
            with factory() as s:alert(s,'worker_tick_failed',datetime.now(JST))
        if args.command=='once':break
        time.sleep(60)
if __name__=='__main__':main()
