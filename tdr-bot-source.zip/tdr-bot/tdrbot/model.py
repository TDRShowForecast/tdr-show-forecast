"""Experience-based scenarios, never fitted statistical probabilities."""
from datetime import datetime, timedelta
from math import isfinite
VERSION = 'experience-0.3.0'

def rank(p):
    return next(r for n, r in [(90,'A'),(70,'B'),(40,'C'),(15,'D'),(0,'E')] if p >= n)

def downwind(direction):
    if not isfinite(direction) or not 0 <= direction < 360:
        raise ValueError('invalid meteorological direction')
    return (direction + 180) % 360

def circular_span(directions):
    if len(directions) < 2: return 0
    a = sorted(directions)
    gaps = [b-a for a,b in zip(a,a[1:])] + [a[0]+360-a[-1]]
    return 360-max(gaps)

def predict(kind, weather, now, *, profile_verified=False):
    from .free_weather import factors
    factor_notes=factors(weather)
    reasons=[]
    def hold(reason):
        return dict(status='hold', probabilities=None, rank=None, reasons=reasons+[reason], model=VERSION, factors=factor_notes)
    if not profile_verified or kind not in ('day','electrical','harbor','fireworks'):
        return hold('公演固有の適用根拠を未確認')
    try:
        age=(now-datetime.fromisoformat(weather['retrieved_at'])).total_seconds()
        if age < -60 or age > 1800: return hold('気象データ取得から30分超または時刻不正')
        if weather.get('source_age_verified') is not True:
            return hold('配信元のデータ更新時刻を未検証')
        for k in ('wind','gust','rain','direction','temperature','humidity'):
            v=weather[k]
            if isinstance(v,bool) or not isinstance(v,(float,int)) or not isfinite(v):return hold('気象値欠損・不正')
        if min(weather['wind'],weather['gust'],weather['rain']) < 0 or not 0 <= weather['humidity'] <= 100:
            return hold('気象値の範囲不正')
        downwind(weather['direction'])
        if weather['gust'] < weather['wind']:return hold('風速の整合性不正')
        if weather.get('lightning') not in ('clear','risk'):return hold('雷評価に必要な情報が不足')
        if weather.get('radar') not in ('clear','approaching'):return hold('雨雲接近情報が不足')
        if weather.get('window_covered') is not True:return hold('公演時間全体の予測が不足')
    except (KeyError,ValueError,TypeError):return hold('気象データの形式不正')
    if weather.get('wbgt_provenance'):reasons.append('WBGTは近隣地点の3時間予測を用いた代理評価')
    w,g,r=weather['wind'],weather['gust'],weather['rain']
    scenarios=[(90,8,2,'穏やかな条件：未検証の基準シナリオ')]
    if kind=='fireworks':
        reasons.append('風下方位 %.0f度（区域・飛散範囲の安全判定には使用しない）'%downwind(weather['direction']))
        if not weather.get('direction_window_complete'):
            return hold('風向変動の時系列不足')
        if weather.get('direction_span') is None:return hold('風向変動値が不足')
        reasons.append('西〜北西は過去の経験上の実施寄り条件' if 270<=weather['direction']<=315 else '経験則の実施寄り風向に該当せず')
        return hold('風下影響を公開情報だけでは定量化できないため、花火の確率は保留')
    if kind=='harbor':
        # Only individually verified profiles may reach this branch.
        if g>=13:scenarios.append((10,15,75,'突風13m/s以上：過去の水上公演経験を個別適用'))
        elif g>=12:scenarios.append((40,25,35,'突風12m/s以上に警戒'))
        if r>=5:reasons.append('強い雨：現行公演への影響は未検証');return hold('雨への耐性の根拠が不足')
    else:
        if g>=13:scenarios.append((5,5,90,'突風13m/s以上：中止90%は主観的な初期仮説'))
        elif g>=12:scenarios.append((25,20,55,'突風12m/s以上に警戒'))
        elif w>=10:scenarios.append((40,30,30,'平均風速10m/s以上に警戒'))
        if r>=5:scenarios.append((5,15,80,'時間降水量5mm以上'))
        elif r>0:scenarios.append((10,10,80,'降雨あり：エレパレは雨に敏感') if kind=='electrical' else (25,60,15,'降雨あり：変更実施に注意'))
        if kind=='day':
            b=weather.get('wbgt')
            if b is None:return hold('WBGTが未取得（気温・湿度で代用しない）')
            if not isinstance(b,(int,float)) or not isfinite(b) or not -30<=b<=60:return hold('WBGT値が不正')
            if b>=32:scenarios.append((5,15,80,'WBGT32以上：熱キャンの経験則'))
            elif b>=31:scenarios.append((10,80,10,'WBGT31以上：ダンサーのカットに注意'))
    if weather['lightning']=='risk':scenarios.append((5,5,90,'雷リスクあり：独立評価'))
    if weather['radar']=='approaching':scenarios.append((15,40,45,'雨雲接近：短縮・変更に注意'))
    # Conservative competing-risk envelope: choose dominant scenario, do not sum correlated hazards.
    s=max(scenarios,key=lambda s:(s[2],s[1]))
    reasons += [x[3] for x in scenarios[1:]] or [s[3]]
    if len(scenarios)>2:reasons.append('複合条件は最大リスクを代表採用。相関の統計モデルは未検証')
    probabilities=dict(normal=s[0],modified=s[1],cancelled=s[2])
    return dict(status='provisional',probabilities=probabilities,rank=rank(s[0]+s[1]),reasons=reasons,model=VERSION,factors=factor_notes)
