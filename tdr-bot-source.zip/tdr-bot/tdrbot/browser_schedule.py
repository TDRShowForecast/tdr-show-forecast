"""Read only rendered public show cards; no hidden endpoint or inferred times."""
import json,os,re
from datetime import datetime,timedelta
from pathlib import Path
from urllib.parse import urlsplit,urljoin
from urllib.robotparser import RobotFileParser
from .sources import BASE,JST

def parse_snapshot(record,park,day,profiles,now):
    expected=f'{BASE}/{park}/daily/calendar/{day.replace("-", "")}/'
    if record.get('status')!='ok' or record.get('method')!='browser_visible_dom':raise ValueError('rendered_schedule_unavailable')
    if record.get('park')!=park or record.get('day')!=day or record.get('source','').rstrip('/')!=expected.rstrip('/'):
        raise ValueError('rendered_schedule_target_mismatch')
    fetched=datetime.fromisoformat(record['retrieved_at'])
    if fetched.tzinfo is None or not timedelta(0)<=now-fetched<=timedelta(minutes=30):raise ValueError('rendered_schedule_stale')
    if not isinstance(record.get('cards'),list) or not record['cards']:raise ValueError('no_rendered_cards')
    found={};unknown={}
    for card in record['cards']:
        match=re.fullmatch(r'/'+park+r'/show/detail/(\d+)/?',card.get('href',''))
        if not match or card.get('visible') is not True:continue
        name=card.get('name','').strip();timetable=card.get('timetable','').strip()
        if not name or not timetable:continue
        sid=park+'-'+match[1];cfg=profiles.get(sid);source=urljoin(BASE,card['href'])
        if cfg is None:
            unknown[sid]=dict(id=sid,name=name,source=source);continue
        if cfg.get('outdoor') is not True:continue
        # Only a displayed list of HH:MM values is a timetable. Never mine prose.
        if not re.fullmatch(r'\d{1,2}:\d{2}(?:\s*/\s*\d{1,2}:\d{2})*',timetable):
            if re.search(r'\d{1,2}:\d{2}',timetable):raise ValueError('ambiguous_rendered_timetable')
            continue
        for time in re.split(r'\s*/\s*',timetable):
            hour,minute=map(int,time.split(':'))
            if hour>23 or minute>59:raise ValueError('invalid_rendered_time')
            start=datetime.fromisoformat(day).replace(hour=hour,minute=minute,tzinfo=JST)
            key=sid+'@'+start.isoformat()
            found[key]=dict(id=key,show_id=sid,name=name,park=park,starts_at=start.isoformat(),
                kind=cfg['kind'],config=cfg,source=source,fetched_at=fetched.isoformat(),retrieval_method='browser_visible_dom')
    return list(found.values()),list(unknown.values())

def from_file(path,park,day,profiles,now=None):
    data=json.loads(Path(path).read_text())
    record=data.get('pages',{}).get(park+':'+day)
    if record is None:raise ValueError('rendered_schedule_missing')
    return parse_snapshot(record,park,day,profiles,now or datetime.now(JST))

CARDS_JS="""anchors => anchors.filter(a => {
 const href=a.getAttribute('href')||'';
 const c=a.querySelector('.timetable'), t=a.querySelector('.heading3');
 return /\\/(tdl|tds)\\/show\\/detail\\/\\d+\\/?$/.test(href) && c && t &&
   a.getClientRects().length>0 && c.getClientRects().length>0 &&
   getComputedStyle(a).visibility!=='hidden' && getComputedStyle(c).visibility!=='hidden';
}).map(a=>({href:a.getAttribute('href'),name:a.querySelector('.heading3').innerText.trim(),
 timetable:a.querySelector('.timetable').innerText.trim(),visible:true}))"""

def is_transport_timeout(error,timeout_class):
    # Chromium can report an OS network timeout as Error, not TimeoutError.
    # Never classify HTTP denials, certificate errors, or robot checks this way.
    return isinstance(error,timeout_class) or any(code in str(error) for code in (
        'net::ERR_TIMED_OUT at ', 'net::ERR_CONNECTION_TIMED_OUT at '))

def collect(output):
    if os.getenv("SCHEDULE_TERMS_REVIEWED")!="true":raise PermissionError("schedule_terms_not_reviewed")
    from playwright.sync_api import sync_playwright,TimeoutError as BrowserTimeout,Error as BrowserError
    from .robots_policy import load_policy
    now=datetime.now(JST);days=[str(now.date()),str(now.date()+timedelta(days=1))]
    result={'method':'browser_visible_dom','pages':{}}
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        context=browser.new_context(locale='ja-JP',timezone_id='Asia/Tokyo')
        page=context.new_page();page.set_default_timeout(20000)
        # Read robots as displayed text too. Keep HTTP rejections as hard failures.
        try:
            response=page.goto(BASE+'/robots.txt',wait_until='domcontentloaded',timeout=45000)
            if not response or response.status!=200:raise ValueError('robots_http_rejection')
            policy=page.locator('body').inner_text()
            if 'user-agent:' not in policy.lower():raise ValueError('robots_not_plain_policy')
        except BrowserError as error:
            if not is_transport_timeout(error,BrowserTimeout):raise
            policy=load_policy() # bounded, verified cache; never a guessed policy
        rp=RobotFileParser();rp.parse(policy.splitlines())
        for park in ('tdl','tds'):
            for day in days:
                url=f'{BASE}/{park}/daily/calendar/{day.replace("-", "")}/';key=park+':'+day
                try:
                    if not rp.can_fetch('TDRWeatherResearchBot',url):raise PermissionError('robots_disallow')
                    response=page.goto(url,wait_until='domcontentloaded',timeout=45000)
                    if not response or response.status!=200:raise ValueError('calendar_http_failure')
                    if page.url.rstrip('/')!=url.rstrip('/'):raise ValueError('calendar_redirected')
                    page.get_by_role('heading',name='当日のスケジュール',exact=True).wait_for(state='visible')
                    page.locator('a .timetable').first.wait_for(state='visible')
                    heading=page.get_by_role('heading',level=1).inner_text()
                    if ('東京ディズニーランド' if park=='tdl' else '東京ディズニーシー') not in heading:raise ValueError('wrong_park_heading')
                    cards=page.locator('a[href]').evaluate_all(CARDS_JS)
                    if not cards:raise ValueError('no_rendered_show_cards')
                    result['pages'][key]=dict(status='ok',method='browser_visible_dom',park=park,day=day,
                        source=page.url,retrieved_at=datetime.now(JST).isoformat(),cards=cards)
                    print(json.dumps({'event':'browser_schedule_read','park':park,'day':day,'cards':len(cards)}),flush=True)
                except Exception as error:
                    result['pages'][key]=dict(status='error',park=park,day=day,error_type=type(error).__name__)
                    print(json.dumps({'event':'browser_schedule_failed','park':park,'day':day,'error_type':type(error).__name__}),flush=True)
        browser.close()
    Path(output).write_text(json.dumps(result,ensure_ascii=False))
    return result

if __name__=='__main__':collect(os.getenv('BROWSER_SCHEDULE_FILE','browser-schedules.json'))
