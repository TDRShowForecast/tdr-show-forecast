"""Offline result import and Brier score. Never treat schedule disappearance as cancellation."""
import argparse,json
from datetime import datetime
from sqlalchemy import select
from .db import connect,Result,Prediction,Performance
OUTCOMES=['normal','modified','cancelled']
def main():
    p=argparse.ArgumentParser();p.add_argument('--import-json');a=p.parse_args()
    with connect()() as s:
        if a.import_json:
            for r in json.load(open(a.import_json)):
                if r['outcome'] not in OUTCOMES or not r.get('source'):raise ValueError('invalid result')
                if not s.get(Performance,r['performance_id']):raise ValueError('unknown performance')
                datetime.fromisoformat(r['confirmed_at'])
                s.merge(Result(id=r['performance_id'],performance_id=r['performance_id'],outcome=r['outcome'],source=r['source'],confirmed_at=r['confirmed_at'],official=r.get('official',False)))
            s.commit()
        scores={}
        for r in s.scalars(select(Result).where(Result.official==True)):
            if r.outcome not in OUTCOMES:continue
            perf=s.get(Performance,r.performance_id)
            for phase in ('前日','朝','30分前','10分前'):
                candidates=s.scalars(select(Prediction).where(Prediction.performance_id==r.performance_id,Prediction.phase==phase,Prediction.created_at<perf.starts_at).order_by(Prediction.created_at.desc())).all()
                pred=next((x for x in candidates if x.payload['probabilities']),None)
                if pred:
                    score=sum((pred.payload['probabilities'][o]/100-int(r.outcome==o))**2 for o in OUTCOMES)
                    scores.setdefault(phase,[]).append(score)
        print(json.dumps({phase:{'n':len(v),'brier':sum(v)/len(v)} for phase,v in scores.items()},ensure_ascii=False))
if __name__=='__main__':main()
