"""Public JMA Edogawa Seaside observations; never treat a period gust as current."""
from datetime import datetime, timedelta
from math import isfinite
from .sources import JST, get
ROOT='https://www.jma.go.jp/bosai/amedas/'
STATION='44136'

def value(record,key,low,high):
    item=record.get(key)
    if not isinstance(item,list) or len(item)!=2 or item[1]!=0:return None
    n=item[0]
    if isinstance(n,bool) or not isinstance(n,(int,float)) or not isfinite(n) or not low<=n<=high:return None
    return n

def parse_point(data,station,now,source,retrieved_at):
    if station.get('kjName')!='江戸川臨海':raise ValueError('wrong_amedas_station')
    if now.tzinfo is None or retrieved_at.tzinfo is None:raise ValueError('timezone_required')
    rows=[]
    for key,row in data.items():
        t=datetime.strptime(key,'%Y%m%d%H%M%S').replace(tzinfo=JST)
        if t<=now:rows.append((t,row))
    if not rows:raise ValueError('no_current_amedas_observation')
    observed,row=max(rows,key=lambda x:x[0])
    if not timedelta(0)<=now-observed<=timedelta(minutes=30):raise ValueError('amedas_observation_stale')
    if not timedelta(0)<=now-retrieved_at<=timedelta(minutes=30):raise ValueError('amedas_retrieval_stale')
    direction=value(row,'windDirection',0,16)
    direction=None if direction in (None,0) else direction*22.5%360
    fields=dict(wind=value(row,'wind',0,150),direction=direction,
        rain_10m=value(row,'precipitation10m',0,1000),rain_1h=value(row,'precipitation1h',0,2000),
        temperature=value(row,'temp',-90,65),humidity=value(row,'humidity',0,100))
    history=[dict(observed_at=t.isoformat(),wind=value(r,'wind',0,150)) for t,r in sorted(rows) if t>=observed-timedelta(hours=1)]
    return dict(provider='気象庁アメダス',station_id=STATION,station_name='江戸川臨海',
        kind='observation',in_park=False,source=source,observed_at=observed.isoformat(),
        retrieved_at=retrieved_at.isoformat(),**fields,wind_history=history,
        # JMA point's gust includes an occurrence time. Aggregation/clock semantics
        # must be verified separately; it is NOT a recent-10-minute gust sample.
        period_max_gust=value(row,'gust',0,150),period_max_gust_time_raw=row.get('gustTime'),
        gust=None,gust_scope='period_maximum_not_used_as_current',wbgt=None)

def fetch_edogawa(now):
    from .free_weather import cached
    station=cached('amedas_station_table',86400,lambda:get(ROOT+'const/amedastable.json',timeout=(20,20)).json())[STATION]
    latest=datetime.fromisoformat(get(ROOT+'data/latest_time.txt',timeout=(20,20)).text.strip()).astimezone(JST)
    if not timedelta(0)<=now-latest<=timedelta(minutes=30):raise ValueError('amedas_latest_time_stale')
    source=ROOT+'data/point/'+STATION+'/'+latest.strftime('%Y%m%d')+'_'+f'{latest.hour//3*3:02d}'+'.json'
    data=get(source,timeout=(20,20)).json()
    finished=datetime.now(JST)
    return parse_point(data,station,finished,source,finished)
