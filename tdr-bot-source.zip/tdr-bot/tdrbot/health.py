from datetime import datetime,timedelta
from .db import connect,State
from .sources import JST

def main():
    with connect()() as s:
        row=s.get(State,'heartbeat')
        if row is None or datetime.now(JST)-datetime.fromisoformat(row.value)>timedelta(minutes=5):
            raise SystemExit(1)
if __name__=='__main__':main()
