"""One host, one process, one local SQLite file. No Supabase/GitHub runtime."""
import argparse,json,os,subprocess,sys,time
from pathlib import Path
from datetime import datetime
from .config import load_env
from .sources import JST

def configure():
    os.environ.setdefault('DATABASE_URL','sqlite:///state/bot.db')
    if not os.environ['DATABASE_URL'].startswith('sqlite:///') or os.getenv('DATABASE_SCHEMA'):
        raise ValueError('simple_mode_requires_local_sqlite_without_schema')
    Path('state').mkdir(exist_ok=True)
    os.environ.setdefault('BROWSER_SCHEDULE_FILE','state/browser-schedules.json')
    os.environ['USE_EDOGAWA_OBSERVATIONS']='true'
    os.environ['CLOUD_MODE']='false'
    os.environ.setdefault('LIVE_POSTING','false')
    os.environ.setdefault('INITIAL_POST_APPROVED','false')

def once(preloaded=False):
    configure()
    if preloaded:
        # Review/test only. Never permit posting from supplied display snapshots.
        os.environ['LIVE_POSTING']='false'
    else:
        code=subprocess.run([sys.executable,'-m','tdrbot.browser_schedule'],timeout=360).returncode
        if code:raise RuntimeError('browser_collection_failed')
    code=subprocess.run([sys.executable,'-m','tdrbot.worker','once'],timeout=300).returncode
    if code:raise RuntimeError('worker_failed')

def main():
    load_env('.env.simple')
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=['once','run','status','pause','resume','weather'])
    parser.add_argument('--preloaded-display',action='store_true');args=parser.parse_args()
    configure()
    if args.preloaded_display and args.command!='once':parser.error('preloaded display is only for offline once review')
    if args.command=='weather':
        from .amedas import fetch_edogawa
        try:print(json.dumps(fetch_edogawa(datetime.now(JST)),ensure_ascii=False,indent=2))
        except Exception as error:
            print(json.dumps({'event':'amedas_failed','error_type':type(error).__name__}));raise SystemExit(1)
        return
    if args.command in ('status','pause','resume'):
        raise SystemExit(subprocess.run([sys.executable,'-m','tdrbot.worker',args.command]).returncode)
    while True:
        started=time.monotonic()
        try:once(args.preloaded_display)
        except Exception as error:
            # No credentials or raw responses in errors. Record a failure, retry next cycle.
            print(json.dumps({'event':'simple_cycle_failed','error_type':type(error).__name__}),flush=True)
            if args.command=='once':raise SystemExit(1)
        if args.command=='once':return
        time.sleep(max(1,600-(time.monotonic()-started)))
if __name__=='__main__':main()
