import json, os, re, hashlib
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urljoin, urlsplit
from urllib.robotparser import RobotFileParser
import requests
from bs4 import BeautifulSoup
from .model import circular_span
JST=__import__('zoneinfo').ZoneInfo('Asia/Tokyo')
BASE='https://www.tokyodisneyresort.jp'
UA='TDRWeatherResearchBot/0.1 (+nonofficial; low-frequency)'

def get(url,**kwargs):
    # A single retry for transient transport failures; never retry access denials.
    for attempt in range(2):
        try:
            r=requests.get(url,timeout=(5,30),headers={'User-Agent':UA},**kwargs)
            r.raise_for_status();return r
        except (requests.exceptions.Timeout,requests.exceptions.ConnectionError):
            if attempt:raise

def parse_schedule(html,park,day,profiles):
    soup=BeautifulSoup(html,'html.parser'); found={}; unknown=[]
    for a in soup.select('a[href]'):
        href=a.get('href','');m=re.fullmatch(r'/'+park+r'/show/detail/(\d+)/?',href)
        if not m:continue
        table=a.select_one('.timetable');title=a.select_one('.heading3')
        if table is None or title is None:continue
        sid=park+'-'+m[1]; name=title.get_text(' ',strip=True)
        cfg=profiles.get(sid)
        if cfg is None:
            unknown.append(dict(id=sid,name=name,source=urljoin(BASE,href)));continue
        if cfg.get('outdoor') is not True:continue
        # Never infer a timetable from unstructured descriptions / duration numbers.
        times=re.findall(r'(?<!\d)([0-2]\d:[0-5]\d)(?!\d)',table.get_text(' ',strip=True))
        for time in times:
            if int(time[:2])>23:raise ValueError('invalid official time')
            start=datetime.fromisoformat(day+'T'+time).replace(tzinfo=JST)
            key=sid+'@'+start.isoformat()
            found[key]=dict(id=key,show_id=sid,name=name,park=park,starts_at=start.isoformat(),
                kind=cfg['kind'],config=cfg,source=urljoin(BASE,href))
    if not soup.select('.timetable'):raise ValueError('schedule markup absent; do not reuse stale schedule')
    return list(found.values()),list({u['id']:u for u in unknown}.values())

class ScheduleSourceError(RuntimeError):
    def __init__(self,stage,cause):
        self.stage=stage
        self.source_error_type=type(cause).__name__
        self.http_status=getattr(getattr(cause,'response',None),'status_code',None)
        super().__init__('official_schedule_'+stage+'_failed')

def fetch_schedule(park,day,profiles):
    if os.getenv("BROWSER_SCHEDULE_FILE"):
        from .browser_schedule import from_file
        return from_file(os.environ["BROWSER_SCHEDULE_FILE"],park,day,profiles)
    # Robots fetched at most once per tick, no bypass of denied resources.
    url=f'{BASE}/{park}/daily/calendar/{day.replace("-", "")}/'
    from .free_weather import cached
    from .robots_policy import load_policy
    try:policy=cached('official_robots',600,load_policy)
    except Exception as error:raise ScheduleSourceError('robots',error) from None
    rp=RobotFileParser();rp.parse(policy.splitlines())
    if not rp.can_fetch(UA,url):raise PermissionError('robots disallows schedule fetch')
    try:r=get(url)
    except Exception as error:raise ScheduleSourceError('calendar',error) from None
    try:return parse_schedule(r.text,park,day,profiles)
    except Exception as error:raise ScheduleSourceError('parse',error) from None

def fetch_weather(park,now):
    from .free_weather import MODEL,META_URL,metadata_freshness,json_source,cached
    lat,lon={'tdl':(35.6329,139.8804),'tds':(35.6267,139.8851)}[park]
    variables='temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,wind_gusts_10m,wind_direction_10m,weather_code'
    # Explicit global model has gusts; do not silently replace missing JMA gusts.
    url='https://api.open-meteo.com/v1/forecast'
    params=dict(latitude=lat,longitude=lon,hourly=variables,models=MODEL,timezone='Asia/Tokyo',wind_speed_unit='ms',forecast_days=3)
    data,retrieved_at=cached('forecast:'+park,900,lambda:(get(url,params=params).json(),now.isoformat()))
    expected={'wind_speed_10m':'m/s','wind_gusts_10m':'m/s','precipitation':'mm','temperature_2m':'°C','relative_humidity_2m':'%','wind_direction_10m':'°'}
    if data.get('utc_offset_seconds')!=32400 or any(data['hourly_units'].get(k)!=v for k,v in expected.items()):
        raise ValueError('unexpected weather units/timezone')
    keys=variables.split(',');h=data['hourly']
    if not h.get('time') or any(len(h[k])!=len(h['time']) for k in keys):raise ValueError('forecast columns')
    freshness=dict(source_age_verified=False,freshness_method='metadata_unavailable')
    try:freshness=metadata_freshness(json_source(META_URL,600),now)
    except Exception:pass
    return dict(provider='Open-Meteo',kind='model_forecast',retrieved_at=retrieved_at,
        issued_at=None,model=MODEL,metadata_source=META_URL,**freshness,
        latitude=data['latitude'],longitude=data['longitude'],grid_elevation=data.get('elevation'),
        hourly=h,units=data['hourly_units'],park=park)

def at_performance(raw,start,duration,now,supplement=None):
    h=raw['hourly'];times=[datetime.fromisoformat(t).replace(tzinfo=JST) for t in h['time']]
    # Hourly precipitation is the preceding hour sum: include interval ending after show ends.
    end=start+timedelta(minutes=duration)
    indexes=[i for i,t in enumerate(times) if start-timedelta(hours=1)<t<=end+timedelta(hours=1)]
    if not indexes:raise ValueError('forecast target outside coverage')
    def values(key):
        return [h.get(key,[None]*len(times))[i] for i in indexes]
    def maximum(key):
        v=values(key)
        return None if any(x is None for x in v) else max(v)
    w=dict(provider=raw['provider'],kind=raw['kind'],retrieved_at=raw['retrieved_at'],
        source_age_verified=raw.get('source_age_verified',False),issued_at=raw.get('issued_at'),
        target_at=start.isoformat(),wind=maximum('wind_speed_10m'),gust=maximum('wind_gusts_10m'),
        rain=maximum('precipitation'),temperature=maximum('temperature_2m'),
        humidity=maximum('relative_humidity_2m'),direction=values('wind_direction_10m')[0],
        direction_span=(None if any(v is None for v in values('wind_direction_10m')) else circular_span(values('wind_direction_10m'))),direction_window_complete=len(indexes)>=2,
        window_covered=min(times)<=start and max(times)>=end and all(b-a==timedelta(hours=1) for a,b in zip(times,times[1:])),wbgt=None,lightning='unknown',radar='unknown')
    w['model']=raw.get('model')
    w['model_provenance']={k:raw.get(k) for k in ('latest_model_initialisation_at','model_available_at','freshness_method','metadata_source')}
    # Preserve cached fetch time, not the time this projection was made.
    w['retrieved_at']=raw['retrieved_at']
    extras=raw.get('extras',{})
    w['extra_sources']=extras
    advisory=extras.get('lightning_advisory',{})
    codes=values('weather_code') if 'weather_code' in h else []
    if advisory.get('status')=='risk' or any(c in (95,96,99) for c in codes):w['lightning']='risk'
    if extras.get('wbgt_series'):
        from .free_weather import wbgt_proxy
        proxy=wbgt_proxy(extras['wbgt_series'],start,end,now)
        if proxy:
            w['wbgt']=proxy['value'];w['wbgt_provenance']=proxy
    if supplement:
        # Contract for a future licensed adapter; each field has its own validity interval.
        allowed={'wbgt','lightning','radar'}
        for item in supplement:
            if item['park']!=raw.get('park') or item['field'] not in allowed:continue
            issued=datetime.fromisoformat(item['issued_at']);retrieved=datetime.fromisoformat(item['retrieved_at'])
            valid0=datetime.fromisoformat(item['valid_from']);valid1=datetime.fromisoformat(item['valid_to'])
            if not item.get('source') or item.get('kind') not in ('observation','forecast'):continue
            if not (timedelta(0)<=now-issued<=timedelta(minutes=30) and timedelta(0)<=now-retrieved<=timedelta(minutes=15)):continue
            if valid0<=start and valid1>=end:
                w[item['field']]=item['value'];w.setdefault('supplement_provenance',[]).append(item)
    return w
