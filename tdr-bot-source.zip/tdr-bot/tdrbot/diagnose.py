"""Read-only connectivity and data-quality check. Never imports a publisher or sends X posts."""
import json
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timedelta
from .config import load_env
from .sources import JST,fetch_weather,at_performance,get
from .free_weather import META_URL,WBGT_URL,WARNING_URL,NOWCAST_URL,metadata_freshness,parse_wbgt_csv,parse_warning,parse_nowcast_timeline,factors
from .model import predict

def check(name,loader):
    try:return name,dict(status='ok',data=loader())
    except Exception as e:
        # Do not print exception messages, which may contain secret URLs or response data.
        return name,dict(status='error',error_type=type(e).__name__)

def run(now):
    tasks={
        'forecast_tdl':lambda:fetch_weather('tdl',now),
        'model_metadata':lambda:metadata_freshness(get(META_URL).json(),now),
        'wbgt_edogawa':lambda:parse_wbgt_csv(get(WBGT_URL).text,now),
        'lightning_advisory':lambda:parse_warning(get(WARNING_URL).json(),now),
        'nowcast_timeline':lambda:parse_nowcast_timeline(get(NOWCAST_URL).json(),now)
    }
    report=dict(checked_at=now.isoformat(),live_posting=False,sources={})
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures=[pool.submit(check,k,f) for k,f in tasks.items()]
        for f in as_completed(futures):
            k,v=f.result();report['sources'][k]=v
    if report['sources']['forecast_tdl']['status']=='ok':
        raw=report['sources']['forecast_tdl']['data']
        raw['extras']={}
        for k,dest in [('wbgt_edogawa','wbgt_series'),('lightning_advisory','lightning_advisory'),('nowcast_timeline','nowcast_timeline')]:
            item=report['sources'][k]
            if item['status']=='ok':raw['extras'][dest]=item['data']
        start=now.replace(minute=0,second=0,microsecond=0)+timedelta(hours=1)
        try:
            w=at_performance(raw,start,30,now)
            report['weather_projection']=w
            report['test_projection_only']=True
            report['target_is_confirmed_performance']=False
            report['prediction']=predict('day',w,now,profile_verified=True)
        except Exception as e:report['projection_error']=type(e).__name__
    else:
        report['prediction']=dict(status='hold',probabilities=None,reasons=['基本気象データを取得できないため数値を出さない'])
    return report

def main():
    load_env();print(json.dumps(run(datetime.now(JST)),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
