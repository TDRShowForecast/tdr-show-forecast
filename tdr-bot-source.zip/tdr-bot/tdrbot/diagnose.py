"""Read-only connectivity and data-quality check. Never imports a publisher or sends X posts."""
import json, os, uuid
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timedelta
from .config import load_env
from .sources import JST,fetch_weather,at_performance,get
from .free_weather import META_URL,WBGT_URL,WARNING_URL,NOWCAST_URL,metadata_freshness,parse_wbgt_csv,parse_warning,parse_nowcast_timeline,factors
from .model import predict

def check(name,loader):
    try:return name,dict(status='ok',data=loader())
    except Exception as e:
        # Do not print exception messages, which may contain secret URLs or response data.
        return name,dict(status='error',error_type=type(e).__name__,http_status=getattr(e,"http_status",getattr(getattr(e,"response",None),"status_code",None)),stage=getattr(e,"stage",None),source_error_type=getattr(e,"source_error_type",None))

def run(now):
    tasks={
        'forecast_tdl':lambda:fetch_weather('tdl',now),
        'model_metadata':lambda:metadata_freshness(get(META_URL).json(),now),
        'wbgt_edogawa':lambda:parse_wbgt_csv(get(WBGT_URL).text,now),
        'lightning_advisory':lambda:parse_warning(get(WARNING_URL).json(),now),
        'nowcast_timeline':lambda:parse_nowcast_timeline(get(NOWCAST_URL).json(),now)
    }
    report=dict(checked_at=now.isoformat(),live_posting=False,sources={})
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures=[pool.submit(check,k,f) for k,f in tasks.items()]
        for f in as_completed(futures):
            k,v=f.result();report['sources'][k]=v
    if report['sources']['forecast_tdl']['status']=='ok':
        raw=report['sources']['forecast_tdl']['data']
        raw['extras']={}
        for k,dest in [('wbgt_edogawa','wbgt_series'),('lightning_advisory','lightning_advisory'),('nowcast_timeline','nowcast_timeline')]:
            item=report['sources'][k]
            if item['status']=='ok':raw['extras'][dest]=item['data']
        start=now.replace(minute=0,second=0,microsecond=0)+timedelta(hours=1)
        try:
            w=at_performance(raw,start,30,now)
            report['weather_projection']=w
            report['test_projection_only']=True
            report['target_is_confirmed_performance']=False
            report['prediction']=predict('day',w,now,profile_verified=True)
        except Exception as e:report['projection_error']=type(e).__name__
    else:
        report['prediction']=dict(status='hold',probabilities=None,reasons=['基本気象データを取得できないため数値を出さない'])
    return report

def verify_storage(report,now):
    """Save diagnostics against confirmed timetables only; never import posting."""
    from sqlalchemy import select,func
    from .sources import fetch_schedule
    from .db import connect,Show,Performance,Weather,Prediction
    from .model import VERSION
    profiles=json.loads(Path(os.getenv('PROFILES_FILE','profiles.json')).read_text())
    result={'posting_enabled':False,'schedule_method':'browser_visible_dom' if os.getenv('BROWSER_SCHEDULE_FILE') else 'http_html','schedules':{},'saved_predictions':0,'saved_weather':0}
    factory=connect()
    with factory() as session:
        for park in ('tdl','tds'):
            name,item=check(park,lambda:fetch_schedule(park,str(now.date()),profiles))
            if item['status']!='ok':
                result['schedules'][park]=item;continue
            rows,unknown=item['data']
            result['schedules'][park]={'status':'ok','performances':len(rows),'unclassified':unknown}
            existing=session.scalars(select(Performance).join(Show,Show.id==Performance.show_id).where(Show.park==park,Performance.starts_at.like(str(now.date())+'%'))).all()
            for old in existing:old.active=False
            for row in rows:
                session.merge(Show(id=row['show_id'],name=row['name'],park=park,kind=row['kind'],config=row['config'],source=row['source']))
                session.merge(Performance(id=row['id'],show_id=row['show_id'],starts_at=row['starts_at'],fetched_at=row.get('fetched_at',now.isoformat()),active=True,source=row['source']))
            session.commit()
            future=[r for r in rows if datetime.fromisoformat(r['starts_at'])>now]
            if not future:continue
            weather_result=report['sources'].get('forecast_tdl') if park=='tdl' else check('forecast_tds',lambda:fetch_weather(park,now))[1]
            result.setdefault('forecast',{})[park]={k:v for k,v in weather_result.items() if k!='data'}
            for row in future:
                wid=None
                if weather_result['status']=='ok':
                    raw=weather_result['data']
                    raw['extras']={dest:report['sources'][key]['data'] for key,dest in [('wbgt_edogawa','wbgt_series'),('lightning_advisory','lightning_advisory'),('nowcast_timeline','nowcast_timeline')] if report['sources'][key]['status']=='ok'}
                    w=at_performance(raw,datetime.fromisoformat(row['starts_at']),row['config'].get('duration_minutes',40),now)
                    wid=str(uuid.uuid4());session.add(Weather(id=wid,retrieved_at=raw['retrieved_at'],target=row['starts_at'],payload=w));result['saved_weather']+=1
                    pred=predict(row['kind'],w,now,profile_verified=row['config'].get('profile_verified',False) and row['config'].get('classification_verified',True))
                else:
                    pred={'status':'hold','probabilities':None,'rank':None,'reasons':['基本気象データ取得失敗'],'model':VERSION,'data_missing':True}
                session.add(Prediction(id=str(uuid.uuid4()),performance_id=row['id'],created_at=now.isoformat(),weather_id=wid,phase='接続確認',model=VERSION,payload=pred));result['saved_predictions']+=1
            session.commit()
        result['database_counts']={m.__tablename__:session.scalar(select(func.count()).select_from(m)) for m in (Show,Performance,Weather,Prediction)}
    return result

def main():
    load_env();now=datetime.now(JST);report=run(now)
    if os.getenv('DATABASE_URL'):
        try:report['storage_verification']=verify_storage(report,now)
        except Exception as e:report['storage_verification']={'status':'error','error_type':type(e).__name__}
    # Persisted weather projections retain provenance; keep public logs concise.
    for item in report['sources'].values():
        data=item.get('data',{})
        if 'hourly' in data:
            data['hourly_points']=len(data.pop('hourly')['time']);data.pop('extras',None)
        if 'points' in data:data['forecast_points']=len(data.pop('points'))
    report.get('weather_projection',{}).pop('extra_sources',None)
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
