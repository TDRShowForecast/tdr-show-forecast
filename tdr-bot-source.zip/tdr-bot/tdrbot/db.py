import os
from datetime import datetime, timezone
from sqlalchemy import create_engine, Column, String, Text, Integer, Boolean, UniqueConstraint, JSON
from sqlalchemy.orm import declarative_base, sessionmaker
Base=declarative_base()
def utc(): return datetime.now(timezone.utc).isoformat()
class Show(Base):
    __tablename__='shows'
    id=Column(String,primary_key=True); name=Column(Text,nullable=False); park=Column(String,nullable=False)
    kind=Column(String,nullable=False); source=Column(Text); config=Column(JSON,nullable=False)
class Performance(Base):
    __tablename__='performances'
    id=Column(String,primary_key=True); show_id=Column(String,nullable=False); starts_at=Column(String,nullable=False)
    fetched_at=Column(String,nullable=False); active=Column(Boolean,default=True); source=Column(Text)
class Weather(Base):
    __tablename__='weather'
    id=Column(String,primary_key=True); retrieved_at=Column(String); target=Column(String); payload=Column(JSON)
class Prediction(Base):
    __tablename__='predictions'
    id=Column(String,primary_key=True); performance_id=Column(String); created_at=Column(String)
    weather_id=Column(String); model=Column(String); payload=Column(JSON); phase=Column(String)
class Result(Base):
    __tablename__='results'
    id=Column(String,primary_key=True); performance_id=Column(String); outcome=Column(String,default='unconfirmed')
    source=Column(Text); confirmed_at=Column(String); official=Column(Boolean,default=False)
class Post(Base):
    __tablename__='posts'
    id=Column(String,primary_key=True); performance_id=Column(String); created_at=Column(String); text=Column(Text)
    status=Column(String); x_id=Column(String); error=Column(Text); fingerprint=Column(String); phase=Column(String)
class State(Base):
    __tablename__='state'
    key=Column(String,primary_key=True); value=Column(Text)
class Incident(Base):
    __tablename__='incidents'
    id=Column(String,primary_key=True); created_at=Column(String); code=Column(String); notified=Column(Boolean,default=False)

def connect(url=None):
    engine=create_engine(url or os.getenv('DATABASE_URL','sqlite:///bot.db'))
    schema=os.getenv('DATABASE_SCHEMA','')
    if schema:
        import re
        from sqlalchemy.schema import CreateSchema
        if engine.dialect.name!='postgresql' or not re.fullmatch(r'[a-z][a-z0-9_]{0,40}',schema):
            raise ValueError('invalid PostgreSQL schema')
        with engine.begin() as conn:conn.execute(CreateSchema(schema,if_not_exists=True))
        # A private schema is not among Supabase's default exposed Data API schemas.
        engine=engine.execution_options(schema_translate_map={None:schema})
    Base.metadata.create_all(engine)
    return sessionmaker(engine,expire_on_commit=False)
