"""GitHub Actions entrypoint. Scheduled runs exit; no persistent VM required."""
import os,sys
from sqlalchemy.engine import make_url

def validate_database_url(value):
    if not value:raise ValueError('DATABASE_URL is required in GitHub Secrets')
    url=make_url(value)
    if url.drivername!='postgresql+psycopg':raise ValueError('Use postgresql+psycopg, not ephemeral SQLite')
    if url.query.get('sslmode') not in ('require','verify-ca','verify-full'):raise ValueError('Database TLS is required')
    if not url.host or not url.username or not url.password:raise ValueError('Database connection details are incomplete')
    if '.pooler.supabase.com' in url.host and url.port!=5432:
        raise ValueError('Use Supabase Session pooler port 5432, not Transaction mode')
    return True

def main():
    operation=os.getenv('CLOUD_OPERATION','diagnose')
    if operation=='diagnose':
        from .diagnose import main as diagnose
        diagnose();return
    if operation not in ('run','pause','resume','status'):raise SystemExit('Unknown cloud operation')
    try:validate_database_url(os.getenv('DATABASE_URL',''))
    except Exception:
        # Do not expose URLs/passwords in a public repository's workflow log.
        print('DB設定を確認してください：PostgreSQL、TLS、Session接続、Secretsが必要です。')
        raise SystemExit(1)
    os.environ['CLOUD_MODE']='true'
    sys.argv=['tdrbot.worker','once' if operation=='run' else operation]
    from .worker import main as worker
    try:worker()
    except Exception as error:
        print("実行失敗："+type(error).__name__+"（設定・DBの接続を確認してください）")
        raise SystemExit(1)
if __name__=='__main__':main()
