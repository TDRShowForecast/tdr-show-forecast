"""Bounded cache of a successfully retrieved official robots policy (RFC 9309 §2.4).
Never use cached policy to override an HTTP denial. Cache outage grace is seven days.
"""
import hashlib,json,os
from datetime import datetime,timedelta,timezone
from pathlib import Path
import requests
SOURCE='https://www.tokyodisneyresort.jp/robots.txt'
KEY='official_robots_policy'

def valid_record(record,now):
    try:
        age=now-datetime.fromisoformat(record['retrieved_at'])
        body=record['text']
        if record['source']!=SOURCE or not timedelta(0)<=age<=timedelta(days=7):return False
        if not isinstance(body,str) or len(body.encode())>512000 or 'user-agent:' not in body.lower():return False
        return hashlib.sha256(body.encode()).hexdigest()==record['sha256']
    except (KeyError,ValueError,TypeError):return False

def load_policy(now=None):
    from .sources import get
    now=now or datetime.now(timezone.utc)
    candidates=[]
    seed=Path(__file__).resolve().parent.parent/'data'/'robots_policy.json'
    try:candidates.append(json.loads(seed.read_text()))
    except (OSError,ValueError):pass
    factory=None
    if os.getenv('DATABASE_URL'):
        from .db import connect,State
        factory=connect()
        with factory() as session:
            row=session.get(State,KEY)
            if row:
                try:candidates.append(json.loads(row.value))
                except ValueError:pass
    candidates=[r for r in candidates if valid_record(r,now)]
    best=max(candidates,key=lambda r:r['retrieved_at'],default=None)
    if best and now-datetime.fromisoformat(best['retrieved_at'])<timedelta(hours=24):
        return best['text']
    try:
        response=get(SOURCE)
        body=response.text
        new=dict(source=SOURCE,retrieved_at=now.isoformat(),text=body,sha256=hashlib.sha256(body.encode()).hexdigest())
        if not valid_record(new,now):raise ValueError('invalid_robots_policy')
    except (requests.exceptions.Timeout,requests.exceptions.ConnectionError):
        if best:
            print(json.dumps({'event':'robots_cached_during_transport_failure','verified_at':best['retrieved_at']}),flush=True)
            return best['text']
        raise
    if factory:
        from .db import State
        with factory() as session:
            session.merge(State(key=KEY,value=json.dumps(new)));session.commit()
    return new['text']
