import hashlib, os, unicodedata
from datetime import timedelta
import requests
from requests_oauthlib import OAuth1
from sqlalchemy import select
from .db import Post, State

def weighted_length(text):
    # Conservative bound: URL text is never compressed; supplementary chars count 2.
    text=unicodedata.normalize('NFC',text)
    return sum(1 if ord(c)<=0x10ff or 0x2000<=ord(c)<=0x200d or 0x2010<=ord(c)<=0x201f or 0x2032<=ord(c)<=0x2037 else 2 for c in text)

def render(show,start,pred,weather,phase):
    name=show.name
    p=pred['probabilities']
    body=(f'通常{p["normal"]}% 変更{p["modified"]}% 中止{p["cancelled"]}%\n実施{p["normal"]+p["modified"]}%【{pred["rank"]}】暫定・未検証' if p else '判定保留：'+pred['reasons'][-1])
    risk='／'.join(pred['reasons'][:2])
    if pred['status']=='hold' and pred.get('factors'):
        risk=pred['factors'].get('wind','')+'／'+pred['factors'].get('rain','')
    info=f'気象取得{weather["retrieved_at"][11:16]} JST\n気象:Open-Meteo(CC BY 4.0)'
    if weather.get('observation'):
        o=weather['observation'];info+=f'\n観測:気象庁 江戸川臨海{o["observed_at"][11:16]}'
    footer='※非公式の独自予測。最新情報はTDR公式サイトで確認。'
    for n,withrisk in [(40,True),(28,True),(18,False),(10,False)]:
        title=name if len(name)<=n else name[:n-1]+'…'
        t=f'【{show.park.upper()}】{title}\n{start:%m/%d %H:%M}公演｜{phase}\n{body}\n'+(risk+'\n' if withrisk else '')+info+'\n'+footer
        if weighted_length(t)<=280:return t
    raise ValueError('post text exceeds weighted limit')

def paused(session):
    row=session.get(State,'paused')
    return row is not None and row.value=='true'

def publish(session,pid,performance_id,phase,text,fingerprint,now,send=None):
    if session.get(Post,pid):return 'duplicate'
    live=os.getenv('LIVE_POSTING')=='true'
    if paused(session):return 'paused'
    recent=session.scalars(select(Post).where(Post.performance_id==performance_id,Post.fingerprint==fingerprint,Post.status.in_(['sent','sending','unknown']))).first()
    if recent:return 'unchanged'
    count=len(list(session.scalars(select(Post).where(Post.created_at>=now.replace(hour=0,minute=0,second=0,microsecond=0).isoformat(),Post.status.in_(['sent','sending','unknown'])))))
    if live and count>=int(os.getenv('MAX_POSTS_PER_DAY','120')):return 'daily_limit'
    if live and os.getenv('INITIAL_POST_APPROVED')!='true':return 'approval_required'
    if live:
        recent_count=len(list(session.scalars(select(Post).where(Post.created_at>=(now-timedelta(minutes=15)).isoformat(),Post.status.in_(['sent','sending','unknown'])))))
        if recent_count>=int(os.getenv('MAX_POSTS_PER_15_MIN','15')):return 'rate_limit'
    record=Post(id=pid,performance_id=performance_id,created_at=now.isoformat(),phase=phase,text=text,
        status='sending' if live else 'dry_run',fingerprint=fingerprint)
    session.add(record);session.commit() # Reserve before network. Never auto-retry uncertain writes.
    if not live:return 'dry_run'
    try:
        if send: xid=send(text)
        else:
            names=['X_API_KEY','X_API_SECRET','X_ACCESS_TOKEN','X_ACCESS_SECRET']
            if not all(os.getenv(n) for n in names):raise ValueError('missing_x_credentials')
            auth=OAuth1(*(os.environ[n] for n in names))
            r=requests.post('https://api.x.com/2/tweets',auth=auth,json={'text':text},timeout=(5,20))
            if r.status_code>=400:
                record.status='failed' if 400<=r.status_code<500 else 'unknown'
                record.error='http_'+str(r.status_code);session.commit();return record.status
            xid=r.json()['data']['id']
        record.x_id=xid;record.status='sent';session.commit();return 'sent'
    except ValueError:
        record.status='unknown';record.error='configuration_or_response_error';session.commit();return 'failed'
    except Exception:
        record.status='unknown';record.error='delivery_outcome_unknown';session.commit();return 'unknown'
