"""Read a local .env as data; never evaluate shell code or print values."""
import json, os, re
from pathlib import Path

def load_env(path='.env'):
    p=Path(path)
    if not p.exists():return
    for line in p.read_text().splitlines():
        line=line.strip()
        if not line or line.startswith('#'):continue
        key,sep,value=line.partition('=')
        if not sep or not re.fullmatch(r'[A-Z][A-Z0-9_]*',key):raise ValueError('invalid env entry')
        value=value.strip()
        if value.startswith('"'):value=json.loads(value)
        elif value.startswith("'") and value.endswith("'"):value=value[1:-1]
        os.environ.setdefault(key,value)
