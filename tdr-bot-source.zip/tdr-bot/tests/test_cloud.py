import pytest
from tdrbot.cloud import validate_database_url

def test_cloud_tls():assert validate_database_url('postgresql+psycopg://bot:secret@db.test:5432/bot?sslmode=require')

def test_session_pool():assert validate_database_url('postgresql+psycopg://bot:secret@aws-0.pooler.supabase.com:5432/postgres?sslmode=require')
@pytest.mark.parametrize('url',['','sqlite:///bot.db','postgresql+psycopg://bot:secret@db.test/bot','postgresql+psycopg://bot@db.test/bot?sslmode=require','postgresql+psycopg://bot:secret@aws-0.pooler.supabase.com:6543/postgres?sslmode=require'])
def test_cloud_rejects(url):
    with pytest.raises(Exception):validate_database_url(url)
