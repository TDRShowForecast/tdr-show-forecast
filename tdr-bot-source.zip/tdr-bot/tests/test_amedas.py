from datetime import datetime,timedelta
import pytest
from tdrbot.amedas import parse_point
from tdrbot.sources import JST
NOW=datetime(2026,11,14,12,20,tzinfo=JST)
def raw():return {'20261114122000':dict(wind=[1.9,0],windDirection=[14,0],temp=[18.9,0],humidity=[47,0],precipitation1h=[0,0],precipitation10m=[0,0],gust=[14,0],gustTime={'hour':18,'minute':54})}
def parse(data=None,now=NOW):return parse_point(data or raw(),{'kjName':'江戸川臨海'},now,'https://www.jma.go.jp/example',now)
def test_measured_station_and_direction():
    o=parse();assert o['kind']=='observation' and o['station_id']=='44136' and o['direction']==315
    assert o['wind']==1.9 and o['rain_1h']==0 and not o['in_park']
def test_period_maximum_never_current_gust():
    o=parse();assert o['period_max_gust']==14 and o['gust'] is None
    assert o['period_max_gust_time_raw']=={'hour':18,'minute':54}
@pytest.mark.parametrize('field,entry',[('wind',[14,1]),('temp',[999,0]),('humidity',[101,0]),('wind',[None,0])])
def test_missing_quality_and_range(field,entry):
    d=raw();d['20261114122000'][field]=entry;o=parse(d)
    assert o[{'temp':'temperature'}.get(field,field)] is None
@pytest.mark.parametrize('delta',[timedelta(hours=1),timedelta(minutes=-1)])
def test_old_or_future_observation_rejected(delta):
    with pytest.raises(ValueError):parse(now=NOW+delta)
def test_wrong_station_rejected():
    with pytest.raises(ValueError):parse_point(raw(),{'kjName':'東京'},NOW,'url',NOW)
def test_calm_has_no_invented_direction():
    d=raw();d['20261114122000']['windDirection']=[0,0];assert parse(d)['direction'] is None

def model_weather():
    return dict(retrieved_at=NOW.isoformat(),source_age_verified=True,wind=3,gust=5,rain=0,direction=315,
        temperature=20,humidity=50,wbgt=20,lightning='clear',radar='clear',window_covered=True)
def test_old_period_gust_does_not_trigger_current_cancel_rule():
    from tdrbot.model import predict
    w=model_weather();w['observation']=parse();w['observation_applied']='near_show_mean_wind_assessment'
    assert predict('day',w,NOW,profile_verified=True)['probabilities']['cancelled']==2

def test_strong_measured_mean_is_risk_without_fabricating_a_gust():
    from tdrbot.model import predict
    w=model_weather();w['observation']={**parse(),'wind':10.5};w['observation_applied']='near_show_mean_wind_assessment'
    result=predict('day',w,NOW,profile_verified=True)
    assert result['probabilities']['cancelled']==30 and w['gust']==5
