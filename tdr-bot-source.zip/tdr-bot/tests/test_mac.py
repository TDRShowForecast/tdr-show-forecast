import importlib.util,os,plistlib
from pathlib import Path
from tdrbot.config import load_env

def test_env_is_data(tmp_path,monkeypatch):
    monkeypatch.delenv('TDR_TEST',raising=False)
    p=tmp_path/'env';p.write_text('TDR_TEST=$(touch /tmp/DO_NOT_EXECUTE)\n')
    load_env(p);assert os.environ['TDR_TEST']=='$(touch /tmp/DO_NOT_EXECUTE)'

def test_env_existing(tmp_path,monkeypatch):
    monkeypatch.setenv('TDR_TEST','existing')
    p=tmp_path/'env';p.write_text('TDR_TEST=new\n');load_env(p)
    assert os.environ['TDR_TEST']=='existing'

def test_env_quotes(tmp_path,monkeypatch):
    monkeypatch.delenv('TDR_TEST',raising=False)
    p=tmp_path/'env';p.write_text('TDR_TEST="a b"\n');load_env(p)
    assert os.environ['TDR_TEST']=='a b'

def test_agent():
    path=Path(__file__).parents[1]/'mac'/'install_mac.py'
    spec=importlib.util.spec_from_file_location('installer',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    target=Path('/Users/test/Library/Application Support/TDRWeatherBot')
    d=plistlib.loads(plistlib.dumps(m.definition(target,target/'.venv/bin/python')))
    assert d['ProgramArguments'][2]==str(target/'.venv/bin/python')
    assert d['WorkingDirectory']==str(target)
    assert 'X_API_KEY' not in d['EnvironmentVariables']
    assert d['KeepAlive'] is True
