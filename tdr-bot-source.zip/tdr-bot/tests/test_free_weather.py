from datetime import datetime,timedelta,timezone
import pytest
from tdrbot.sources import JST,at_performance
from tdrbot.free_weather import metadata_freshness,parse_wbgt_csv,wbgt_proxy,parse_warning,parse_nowcast_timeline,factors
NOW=datetime(2026,6,23,18,40,tzinfo=JST)

def meta(age=1200,init=36000):
    return dict(last_run_initialisation_time=(NOW-timedelta(seconds=init)).timestamp(),last_run_availability_time=(NOW-timedelta(seconds=age)).timestamp(),update_interval_seconds=21600)
@pytest.mark.parametrize('age,fresh',[(599,False),(600,True),(1200,True),(28800,True),(28801,False),(-1,False)])
def test_metadata(age,fresh):assert metadata_freshness(meta(age),NOW)['source_age_verified']==fresh

def test_metadata_missing():assert metadata_freshness({},NOW)['source_age_verified'] is False

def test_metadata_future_init():assert metadata_freshness(meta(init=-10),NOW)['source_age_verified'] is False

CSV=',,2026062318,2026062321,2026062324,2026062403\n44136,2026/06/23 18:10, 300, 310, 270, 250\n'
def test_wbgt_scale_midnight():
    s=parse_wbgt_csv(CSV,NOW)
    assert s['points'][1]['value']==31
    assert s['points'][2]['target_at']=='2026-06-24T00:00:00+09:00'
    p=wbgt_proxy(s,NOW,NOW+timedelta(minutes=30),NOW)
    assert p['value']==31 and p['in_park'] is False and p['method']=='adjacent_3hour_max_proxy'

def test_wbgt_stale():
    s=parse_wbgt_csv(CSV,NOW);assert wbgt_proxy(s,NOW,NOW+timedelta(minutes=30),NOW+timedelta(hours=2)) is None

def test_wbgt_missing():
    s=parse_wbgt_csv(CSV.replace('310',''),NOW)
    assert wbgt_proxy(s,NOW,NOW+timedelta(minutes=30),NOW) is None

def test_wbgt_not_extrapolate():
    s=parse_wbgt_csv(CSV,NOW)
    assert wbgt_proxy(s,NOW-timedelta(hours=3),NOW,NOW) is None
@pytest.mark.parametrize('csv',[CSV.replace('44136','99999'),CSV.replace('310','999'),CSV.replace('2026062324','2026062325'),CSV.replace('310','311')])
def test_wbgt_bad(csv):
    with pytest.raises(ValueError):parse_wbgt_csv(csv,NOW)

def warning(warnings):return dict(reportDatetime=NOW.isoformat(),areaTypes=[{'areas':[{'code':'1222700','warnings':warnings}]}])
def test_thunder_positive():assert parse_warning(warning([{'code':'14','status':'継続'}]),NOW)['status']=='risk'
@pytest.mark.parametrize('warnings',[[],[{'code':'14','status':'解除'}],[{'code':'15','status':'発表'}]])
def test_thunder_absence_not_clear(warnings):assert parse_warning(warning(warnings),NOW)['status']=='unknown'

def test_warning_stale():assert parse_warning(warning([{'code':'14','status':'継続'}]),NOW+timedelta(days=2))['status']=='unknown'

def test_timeline_not_rain_measurement():
    b=NOW.astimezone(timezone.utc)-timedelta(minutes=5)
    rows=[dict(basetime=b.strftime('%Y%m%d%H%M%S'),validtime=(b+timedelta(hours=1)).strftime('%Y%m%d%H%M%S'),elements=['hrpns'])]
    assert parse_nowcast_timeline(rows,NOW)['status']=='timeline_available'
    assert parse_nowcast_timeline(rows,NOW)['radar']=='unknown'
    assert parse_nowcast_timeline(rows,NOW+timedelta(hours=1))['status']=='stale_or_missing'

def test_partial_factors():
    f=factors({'gust':13,'rain':5,'lightning':'unknown','radar':'unknown'})
    assert '13' in f['wind'] and '不足' in f['lightning'] and '未取得' in f['heat']

def test_fetch_caches_original_retrieval(monkeypatch):
    import tdrbot.sources as source
    import tdrbot.free_weather as free
    free._cache.clear()
    unit=dict(wind_speed_10m='m/s',wind_gusts_10m='m/s',precipitation='mm',temperature_2m='°C',relative_humidity_2m='%',wind_direction_10m='°')
    variables='temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,wind_gusts_10m,wind_direction_10m,weather_code'.split(',')
    data=dict(latitude=35.625,longitude=139.875,utc_offset_seconds=32400,hourly_units=unit,hourly={k:[1,2] for k in variables})
    data['hourly']['time']=['2026-06-23T18:00','2026-06-23T19:00']
    class Response:
        def json(self):return data
    monkeypatch.setattr(source,'get',lambda *a,**kw:Response())
    monkeypatch.setattr(free,'json_source',lambda *a:meta())
    a=source.fetch_weather('tdl',NOW);b=source.fetch_weather('tdl',NOW+timedelta(minutes=5))
    assert a['retrieved_at']==b['retrieved_at']==NOW.isoformat()
    assert a['model']=='icon_global' and a['source_age_verified'] is True
    assert a['issued_at'] is None # Never claim an exact issuance timestamp for stitched output.
    free._cache.clear()

def test_partial_weather_null_is_held():
    h=dict(time=['2026-06-23T18:00','2026-06-23T19:00','2026-06-23T20:00'],temperature_2m=[25]*3,relative_humidity_2m=[60]*3,precipitation=[0]*3,wind_speed_10m=[3]*3,wind_gusts_10m=[None]*3,wind_direction_10m=[280]*3)
    raw=dict(hourly=h,provider='test',kind='model_forecast',retrieved_at=NOW.isoformat(),source_age_verified=True)
    w=at_performance(raw,NOW,30,NOW)
    from tdrbot.model import predict
    p=predict('day',w,NOW,profile_verified=True)
    assert p['status']=='hold' and '未取得' in p['factors']['wind']

def test_hourly_gap_is_not_covered():
    h=dict(time=['2026-06-23T18:00','2026-06-23T20:00'],temperature_2m=[25]*2,relative_humidity_2m=[60]*2,precipitation=[0]*2,wind_speed_10m=[3]*2,wind_gusts_10m=[5]*2,wind_direction_10m=[280]*2)
    raw=dict(hourly=h,provider='test',kind='model_forecast',retrieved_at=NOW.isoformat(),source_age_verified=True)
    assert at_performance(raw,NOW,30,NOW)['window_covered'] is False
