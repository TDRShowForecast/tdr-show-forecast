import requests,pytest
from tdrbot import sources

def test_transient_timeout_retries_once(monkeypatch):
    calls=[]
    class Response:
        def raise_for_status(self):pass
    def request(*a,**k):
        calls.append(1)
        if len(calls)==1:raise requests.ReadTimeout()
        return Response()
    monkeypatch.setattr(requests,'get',request)
    assert sources.get('https://example.test')
    assert len(calls)==2

def test_access_denial_is_not_retried(monkeypatch):
    calls=[]
    def request(*a,**k):
        calls.append(1);raise requests.HTTPError()
    monkeypatch.setattr(requests,'get',request)
    with pytest.raises(requests.HTTPError):sources.get('https://example.test')
    assert len(calls)==1
