import pytest
@pytest.fixture(autouse=True)
def no_live_extra_requests(monkeypatch):
    # Automated tests never contact external providers.
    monkeypatch.setattr('tdrbot.free_weather.fetch_free_extras',lambda now:{})
