from datetime import datetime,timedelta
import pytest
from tdrbot.browser_schedule import parse_snapshot
from tdrbot.sources import JST
NOW=datetime(2026,11,14,11,tzinfo=JST)
PROFILES={'tdl-1':{'outdoor':True,'kind':'day'},'tdl-2':{'outdoor':False,'kind':'indoor'}}
def snapshot():
    return dict(status='ok',method='browser_visible_dom',park='tdl',day='2026-11-14',source='https://www.tokyodisneyresort.jp/tdl/daily/calendar/20261114/',retrieved_at=NOW.isoformat(),cards=[dict(href='/tdl/show/detail/1/',name='Displayed show',timetable='12:45 / 15:25',visible=True)])
def test_rendered_times_and_provenance():
    rows,unknown=parse_snapshot(snapshot(),'tdl','2026-11-14',PROFILES,NOW)
    assert len(rows)==2 and not unknown
    assert rows[0]['starts_at']=='2026-11-14T12:45:00+09:00'
    assert rows[1]['retrieval_method']=='browser_visible_dom'
@pytest.mark.parametrize('field,value',[('day','2026-11-15'),('park','tds'),('source','https://example.org/'),('status','error'),('retrieved_at',(NOW-timedelta(hours=1)).isoformat())])
def test_wrong_or_stale_page_rejected(field,value):
    record=snapshot();record[field]=value
    with pytest.raises(ValueError):parse_snapshot(record,'tdl','2026-11-14',PROFILES,NOW)
@pytest.mark.parametrize('value',['24:00','12:70','9:00 - 21:00'])
def test_invalid_or_range_not_inferred(value):
    record=snapshot();record['cards'][0]['timetable']=value
    with pytest.raises(ValueError):parse_snapshot(record,'tdl','2026-11-14',PROFILES,NOW)
def test_hidden_and_indoor_cards_ignored():
    record=snapshot();record['cards'][0]['visible']=False
    record['cards'].append(dict(href='/tdl/show/detail/2/',name='Indoor',timetable='12:45',visible=True))
    assert parse_snapshot(record,'tdl','2026-11-14',PROFILES,NOW)==([],[])
def test_reservation_prose_has_no_invented_time():
    record=snapshot();record['cards'][0]['timetable']='予約時にご確認ください'
    assert parse_snapshot(record,'tdl','2026-11-14',PROFILES,NOW)==([],[])
