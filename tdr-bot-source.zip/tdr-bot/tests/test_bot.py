from datetime import datetime,timedelta
from types import SimpleNamespace
import pytest
from sqlalchemy import select
from tdrbot.model import predict,rank,downwind,circular_span
from tdrbot.db import connect,Post,State
from tdrbot.sources import JST,parse_schedule,at_performance
from tdrbot.posting import publish,render,weighted_length
from tdrbot.worker import phase_for,tick
NOW=datetime(2026,11,11,12,tzinfo=JST)
def weather():
    return dict(retrieved_at=NOW.isoformat(),source_age_verified=True,wind=3,gust=5,rain=0,direction=280,temperature=25,humidity=60,wbgt=25,lightning='clear',radar='clear',window_covered=True,direction_window_complete=True,direction_span=10)
def pred(kind='day',**kw):
    w=weather();w.update(kw);return predict(kind,w,NOW,profile_verified=True)
@pytest.mark.parametrize('p,r',[(100,'A'),(90,'A'),(89,'B'),(70,'B'),(69,'C'),(40,'C'),(39,'D'),(15,'D'),(14,'E'),(0,'E')])
def test_rank(p,r):assert rank(p)==r
@pytest.mark.parametrize('g',[0,5,11.9,12,12.9,13,20])
def test_total(g):
    p=pred(gust=g,wind=0)['probabilities'];assert sum(p.values())==100 and min(p.values())>=0

def test_wind90():assert pred(gust=13)['probabilities']['cancelled']==90

def test_electrical_rain():assert pred('electrical',rain=.01)['probabilities']['cancelled']>pred(rain=.01)['probabilities']['cancelled']

def test_heat():
    assert pred(wbgt=31)['probabilities']['modified']==80
    assert pred(wbgt=32)['probabilities']['cancelled']==80

def test_harbor():
    assert pred('harbor',wbgt=40)['probabilities']==pred('harbor',wbgt=20)['probabilities']
    assert predict('harbor',weather(),NOW)['status']=='hold'

def test_compound():assert pred(gust=13,rain=10,wbgt=34)['probabilities']['cancelled']==90
@pytest.mark.parametrize('field,value',[('wind',None),('gust',float('nan')),('direction',360),('wind',-1),('humidity',150),('lightning','unknown'),('radar','unknown'),('window_covered',False),('wbgt',None),('source_age_verified',False),('gust',2)])
def test_holds(field,value):assert pred(**{field:value})['status']=='hold'
@pytest.mark.parametrize('minutes',[-31,5])
def test_time(minutes):assert pred(retrieved_at=(NOW+timedelta(minutes=minutes)).isoformat())['status']=='hold'
@pytest.mark.parametrize('direction',[0,90,270,300,315])
def test_firework(direction):assert pred('fireworks',direction=direction,gust=12)['probabilities'] is None

def test_directions():assert downwind(270)==90 and downwind(315)==135 and circular_span([350,0,10])==20
@pytest.fixture
def factory():return connect('sqlite:///:memory:')

def test_parser():
    h='<a href="/tdl/show/detail/1/"><p class="heading3">Test</p><div class="timetable">15:00 / 17:30</div></a><a href="/tdl/show/detail/2/"><p class="heading3">Unknown</p><div class="timetable">16:00</div></a>'
    rows,unknown=parse_schedule(h,'tdl','2026-11-11',{'tdl-1':{'outdoor':True,'kind':'day'}})
    assert len(rows)==2 and len(unknown)==1 and rows[0]['starts_at']=='2026-11-11T15:00:00+09:00'

def test_missing_markup():
    with pytest.raises(ValueError):parse_schedule('<p>15:00</p>','tdl','2026-11-11',{})

def test_no_invented_time():
    h='<a href="/tdl/show/detail/1/"><p class="heading3">Test</p><div class="timetable">休止</div></a>'
    assert parse_schedule(h,'tdl','2026-11-11',{'tdl-1':{'outdoor':True,'kind':'day'}})[0]==[]
@pytest.mark.parametrize('d,e',[(121,None),(120,'重点監視'),(61,'重点監視'),(60,'1時間前'),(31,'1時間前'),(30,'30分前'),(11,'30分前'),(10,'10分前'),(0,None)])
def test_phase(d,e):assert phase_for(NOW+timedelta(minutes=d),NOW)==e

def test_jst():
    assert phase_for(NOW+timedelta(days=1),NOW.replace(hour=20))=='前日'
    assert phase_for(NOW,NOW.replace(hour=7))=='朝'

def test_render():
    show=SimpleNamespace(name='超長い公演名'*30,park='tdl')
    for p in [pred(),pred(lightning='unknown'),pred(gust=13,rain=10,wbgt=34)]:
        t=render(show,NOW,p,weather(),'30分前');assert weighted_length(t)<=280 and '非公式' in t

def test_dry_duplicate(factory,monkeypatch):
    monkeypatch.delenv('LIVE_POSTING',raising=False)
    with factory() as s:
        assert publish(s,'p','perf','朝','test','f',NOW)=='dry_run'
        assert publish(s,'p','perf','朝','test','f',NOW)=='duplicate'

def test_approval(factory,monkeypatch):
    monkeypatch.setenv('LIVE_POSTING','true');monkeypatch.delenv('INITIAL_POST_APPROVED',raising=False)
    with factory() as s:assert publish(s,'p','perf','朝','test','f',NOW)=='approval_required'

def test_pause(factory):
    with factory() as s:
        s.add(State(key='paused',value='true'));s.commit()
        assert publish(s,'p','perf','朝','test','f',NOW)=='paused'

def test_uncertain(factory,monkeypatch):
    monkeypatch.setenv('LIVE_POSTING','true');monkeypatch.setenv('INITIAL_POST_APPROVED','true');calls=[]
    def send(t):calls.append(t);raise TimeoutError()
    with factory() as s:
        assert publish(s,'p','perf','朝','test','f',NOW,send)=='unknown'
        assert publish(s,'q','perf','直前','test','f',NOW,send)=='unchanged'
        assert len(calls)==1

def test_cap(factory,monkeypatch):
    monkeypatch.setenv('LIVE_POSTING','true');monkeypatch.setenv('INITIAL_POST_APPROVED','true');monkeypatch.setenv('MAX_POSTS_PER_DAY','1')
    with factory() as s:
        assert publish(s,'p','perf','朝','test','f',NOW,lambda t:'123')=='sent'
        assert publish(s,'q','perf2','朝','test','g',NOW,lambda t:'124')=='daily_limit'

def test_terms_gate(factory,monkeypatch):
    monkeypatch.delenv('SCHEDULE_TERMS_REVIEWED',raising=False)
    with factory() as s:
        tick(s,NOW,{})
        assert s.get(State,'alert:schedule_terms_not_reviewed') is not None
        assert not s.scalars(select(Post)).all()

def test_complete_dry_pipeline(factory,monkeypatch):
    import tdrbot.worker as worker
    from tdrbot.db import Prediction,Performance
    monkeypatch.setenv('SCHEDULE_TERMS_REVIEWED','true');monkeypatch.setenv('LIVE_POSTING','false')
    start=NOW+timedelta(minutes=30)
    row=dict(id='tdl-1@'+start.isoformat(),show_id='tdl-1',name='テスト公演',park='tdl',starts_at=start.isoformat(),kind='day',config={'duration_minutes':30,'profile_verified':True},source='https://www.tokyodisneyresort.jp/tdl/show/detail/1/')
    monkeypatch.setattr(worker,'fetch_schedule',lambda park,day,profiles:([row] if park=='tdl' and day==str(NOW.date()) else [],[]))
    monkeypatch.setattr(worker,'fetch_weather',lambda park,now:{'park':park})
    monkeypatch.setattr(worker,'at_performance',lambda *a:weather())
    with factory() as s:
        tick(s,NOW,{})
        assert len(s.scalars(select(Post)).all())==1
        assert s.scalars(select(Post)).first().status=='dry_run'
        assert s.scalars(select(Prediction)).first().payload['probabilities']['normal']==90
        tick(s,NOW+timedelta(minutes=1),{})
        assert len(s.scalars(select(Post)).all())==1

def test_weather_precip_window_and_no_false_freshness():
    times=['2026-11-11T11:00','2026-11-11T12:00','2026-11-11T13:00','2026-11-11T14:00']
    h=dict(time=times,temperature_2m=[25]*4,relative_humidity_2m=[60]*4,precipitation=[0,0,5,0],wind_speed_10m=[3]*4,wind_gusts_10m=[5]*4,wind_direction_10m=[350,0,10,0])
    raw=dict(hourly=h,provider='test',kind='model_forecast',retrieved_at=NOW.isoformat(),source_age_verified=False,park='tdl')
    w=at_performance(raw,NOW+timedelta(minutes=30),30,NOW)
    assert w['rain']==5 and w['source_age_verified'] is False
    assert predict('day',w,NOW,profile_verified=True)['status']=='hold'
