import hashlib,json
from datetime import datetime,timedelta,timezone
import requests,pytest
from tdrbot import robots_policy as rp,sources
NOW=datetime(2026,11,14,tzinfo=timezone.utc)
def record(age):
    body='User-agent: *\nDisallow: /app/\n'
    return dict(source=rp.SOURCE,retrieved_at=(NOW-age).isoformat(),text=body,sha256=hashlib.sha256(body.encode()).hexdigest())
@pytest.mark.parametrize('age,ok',[(timedelta(hours=1),True),(timedelta(days=8),False),(timedelta(hours=-1),False)])
def test_cache_age(age,ok):assert rp.valid_record(record(age),NOW)==ok

def setup_cache(monkeypatch,age):
    monkeypatch.delenv('DATABASE_URL',raising=False)
    monkeypatch.setattr(rp.Path,'read_text',lambda *a,**k:json.dumps(record(age)))

def test_recent_verified_cache_does_not_need_fetch(monkeypatch):
    setup_cache(monkeypatch,timedelta(hours=1))
    def fail(*a,**k):raise AssertionError('unnecessary fetch')
    monkeypatch.setattr(sources,'get',fail)
    assert 'User-agent' in rp.load_policy(NOW)

def test_timeout_allows_bounded_previous_policy(monkeypatch):
    setup_cache(monkeypatch,timedelta(days=2))
    def fail(*a,**k):raise requests.ReadTimeout()
    monkeypatch.setattr(sources,'get',fail)
    assert 'Disallow' in rp.load_policy(NOW)

def test_denial_never_uses_cached_policy(monkeypatch):
    setup_cache(monkeypatch,timedelta(days=2))
    def fail(*a,**k):raise requests.HTTPError()
    monkeypatch.setattr(sources,'get',fail)
    with pytest.raises(requests.HTTPError):rp.load_policy(NOW)

def test_expired_cache_cannot_allow_fetch_after_timeout(monkeypatch):
    setup_cache(monkeypatch,timedelta(days=8))
    def fail(*a,**k):raise requests.ReadTimeout()
    monkeypatch.setattr(sources,'get',fail)
    with pytest.raises(requests.ReadTimeout):rp.load_policy(NOW)
