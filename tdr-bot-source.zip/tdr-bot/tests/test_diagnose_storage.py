from datetime import datetime
from sqlalchemy import select
from tdrbot import diagnose,db,sources
from tdrbot.sources import JST

def test_failed_weather_saves_hold_for_real_show_without_posting(monkeypatch,tmp_path):
    monkeypatch.setenv('DATABASE_URL','sqlite:///'+str(tmp_path/'bot.db'))
    monkeypatch.delenv('DATABASE_SCHEMA',raising=False)
    now=datetime(2026,11,14,10,tzinfo=JST)
    row=dict(id='tdl-7000@confirmed',show_id='tdl-7000',name='Official show',park='tdl',kind='day',starts_at='2026-11-14T15:00:00+09:00',config={'profile_verified':True},source='https://www.tokyodisneyresort.jp/')
    monkeypatch.setattr(sources,'fetch_schedule',lambda park,*args:([row],[]) if park=='tdl' else ([],[]))
    result=diagnose.verify_storage({'sources':{'forecast_tdl':{'status':'error','error_type':'ReadTimeout'}}},now)
    assert result['saved_predictions']==1 and result['saved_weather']==0
    with db.connect()() as session:
        pred=session.scalar(select(db.Prediction))
        assert pred.payload['status']=='hold' and pred.weather_id is None
        assert session.scalar(select(db.Post)) is None

def test_schedule_failure_does_not_create_performances(monkeypatch,tmp_path):
    monkeypatch.setenv('DATABASE_URL','sqlite:///'+str(tmp_path/'bot.db'))
    monkeypatch.delenv('DATABASE_SCHEMA',raising=False)
    def fail(*a):raise TimeoutError('do not echo confidential context')
    monkeypatch.setattr(sources,'fetch_schedule',fail)
    result=diagnose.verify_storage({'sources':{}},datetime(2026,11,14,10,tzinfo=JST))
    assert result['database_counts']['performances']==0
    assert result['schedules']['tdl']['error_type']=='TimeoutError'
    assert 'confidential' not in str(result)
