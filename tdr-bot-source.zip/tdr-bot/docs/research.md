# データ源・運用サービス調査

調査日：2026-11-11（日本時間）。公式の公開ページを参照。未確認事項は契約可能・無料利用可能と断定しない。

| 情報源 | 用途・更新・位置精度 | 利用条件と判断 |
|---|---|---|
| TDR日別カレンダー | 公演名・日別予定時刻。更新保証・API SLAは未確認 | HTML解析可能。コンテンツ使用制限あり。利用を許される取得・再利用経路の確認前は自動取得停止 |
| Open-Meteo | 平均風・突風・風向・1時間降水・気温・湿度。モデル依存の格子予測。パーク内実測ではない | Freeは非商用のみ。CC BY 4.0、1日1万・1時間5000・1分600回未満。商用は有料契約が必要。モデル初期時刻を取得時刻で代用しない |
| 気象庁 | 高解像度降水ナウキャストは短時間の雨雲評価、雷ナウキャストは雷活動 | Web表示を非公開APIや安定SLAとみなさない。配信経路・形式・利用条件の確認後に接続 |
| 環境省 | CSVのWBGT予測・実況推定。地点別でパーク実測とは異なる | 2026年度サービスは10/21終了。過去CSVを現在値として使用不可。提供ページの詳細規約と地点の選定が必要 |
| 日本気象株式会社 | 高解像度降水・雷ナウキャストのHTTP等による提供候補 | 料金確認には登録が必要なサービスあり。未契約・未ログイン。最終候補。雷・雨雲の再配布可否と派生予測投稿の許諾を確認 |
| 気象業務支援センター | JMAデータの正式オンライン配信経路候補 | 情報別料金に加え基本・通信等が必要。雷単体価格を月額総額として扱わない。受信・デコードの開発が必要 |
| ハレックス | 雷ナウキャスト。1km格子、10〜60分先 | 公開ページに月額2万円＋基本1.25万円（税別）の例。雨雲等は別。小規模Bot向け最安と断定しない |
| X | POST /2/tweets、OAuth 1.0a User認証 | 通常0.015米ドル/件、URL付き0.200米ドル/件（調査時点）。公式API以外の投稿自動化は使わない |
| Railway | WorkerとPostgreSQLの候補 | Hobby最低5米ドル/月＋超過使用量。見積・上限・DBバックアップを設定してから承認 |
| Render | Worker・PostgreSQLの比較候補 | 今回の料金ページ取得では構成総額を確定できず、金額未記載 |

## 一次情報リンク

- 公演情報例： https://www.tokyodisneyresort.jp/tdl/daily/calendar/20261111/
- シー公演情報例： https://www.tokyodisneyresort.jp/tds/daily/calendar/20261111/
- TDR利用条件： https://www.tokyodisneyresort.jp/legal.html
- Open-Meteo API： https://open-meteo.com/en/docs
- Open-Meteo利用条件： https://open-meteo.com/en/terms
- Open-Meteo料金： https://open-meteo.com/en/pricing
- WBGT CSV案内： https://www.wbgt.env.go.jp/data_service.php
- JMA高解像度降水： https://www.jma.go.jp/jma/kishou/know/kurashi/highres_nowcast.html
- JMA開発者向け案内： https://www.data.jma.go.jp/developer/weatherdataguide/appendix/2-1-b.html
- 日本気象株式会社・雷： https://ods.n-kishou.co.jp/data/detail/555
- 日本気象株式会社・降水： https://ods.n-kishou.co.jp/data/detail/5986
- 気象業務支援センター負担金： https://www.jmbsc.or.jp/jp/online/c-onlineF.html
- ハレックス雷： https://www.halex.co.jp/service/smart/thunder-nowcast/
- X料金： https://developer.x.com/
- X投稿： https://docs.x.com/x-api/posts/create-post
- X自動化規則： https://help.x.com/en/rules-and-policies/x-automation
- Railway： https://railway.com/pricing
- Render： https://render.com/pricing

## 本番前の確認事項

公演スケジュールの情報利用許容と供給方法を先に確定する。次に、必要気象項目・発表時刻・過去予測保存・派生予測のSNS公開を許す気象サービスを見積もる。前日予測と直前ナウキャストは異なる時間範囲を持つので、一律の欠損補完で埋めない。商用化・広告・アフィリエイト等を行う場合はOpen-Meteo無料枠の適用を再検討する。

具体的な打上位置、安全区域、内部運営閾値の取得や復元は実施していない。
