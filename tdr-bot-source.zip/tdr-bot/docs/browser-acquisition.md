# 公式サイトの表示からの取得検証（2026年11月14日）

- Playwright Chromiumで表示し、見える公演カードの公演名・時刻をinnerTextで取得。
- 隠しAPI、内部データ、推定時刻は使わない。
- パーク、日付、URL、取得時刻、時刻形式を検証。30分超・ページ取得失敗・曖昧な時刻は不採用。
- チャットのブラウザに表示された内容を抽出し、TDL14件・TDS12件の設定済み屋外候補公演回に変換できた。屋外分類未検証の公演は予測保留。
- 自動テスト122件通過。
- GitHub Actions実行#12ではChromium起動成功、公式カレンダー4ページはすべてTimeoutError。公演・気象・予測保存0件。
- 実行URL: https://github.com/TDRShowForecast/tdr-show-forecast/actions/runs/43549058571
- 直接HTML取得もGitHub Linux/macOSでタイムアウト、Supabase Edge東京のrobots疎通もタイムアウト。サイトのボット検出だと断定できる画面は確認していない。
- 定期実行とX投稿は無効。チャットのブラウザでの抽出成功は、クラウドの無人取得成功を意味しない。

次の条件は、常時実行先で同じ公式ページが正常表示できること。取得処理を導入しただけでは本番開始しない。現状の無料構成で完全自動化は未達。新しい有料サービスの契約やX投稿は実施しない。

## 追加検証

GitHub macOSブラウザ実行#13もrobots.txtにnet::ERR_TIMED_OUT。カレンダー未到達。PlaywrightのErrorとして返るネットワークタイムアウトの分類を修正し、検証済みキャッシュの既存期限のみを適用する。HTTP拒否・TLSエラー・人間確認では利用しない。修正後128テスト通過、接続解消は未確認。

実行: https://github.com/TDRShowForecast/tdr-show-forecast/actions/runs/43550027080
