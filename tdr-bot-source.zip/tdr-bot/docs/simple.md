# 単純版：1プロセス＋ローカル記録（2026年11月14日）

## 採用構成

ブラウザで公式公演表示を読む → 気象庁アメダス江戸川臨海の実測＋公演時刻の予報 → 依頼者の経験則 → X投稿。1台の実行先で1プロセスを動かし、記録は同じ場所のSQLiteに保存。SupabaseやGitHub Actionsを実行基盤にしない。GitHubはコードの保管だけに使用する。古いクラウド構成のファイルは比較・復旧用として残すが、この構成では起動しない。

## 江戸川臨海

観測所44136で、公式観測所表の名称も照合する。気象庁の公開表示用データから10分平均風速・16方位の風向・10分/1時間降水量・気温・湿度を取得。品質コード0のみ使用、欠測は補完せずnull。観測時刻と取得時刻を別々に記録し、30分超の観測を不採用にする。パーク内の実測値とは扱わない。

公演30分前以内では、平均風速10m/s以上の実測を風リスクの候補シナリオに追加する初期仮説を実装。未来の予報を観測値で上書きしない。最大瞬間風速は、公開pointデータのgust値に過去の発生時刻が伴うため期間最大値として分離し、直近の突風として12/13m/sの基準に投入しない。期間・時刻表現の確認後に別途扱う。気温からWBGTを作らない。

公式説明：
- https://www.jma.go.jp/jma/kishou/know/amedas/kaisetsu.html
- https://www.jma.go.jp/jma/kishou/know/faq/faq2.html

## 起動

.env.simple.example を .env.simple にコピーして必要な値を保存する。秘密値をチャットに貼らない。データを消さないようstateを永続化する。

```
python -m pip install -r requirements.txt
python -m playwright install --with-deps chromium
python -m tdrbot.simple weather
python -m tdrbot.simple once
python -m tdrbot.simple run
```

runは約10分周期。取得失敗時はログを残して次周期で再取得する。Xの送信結果が不明な場合は重複を避けるため自動再送しない。初期状態は実投稿無効。X認証と初回承認後にだけ有効にする。

Docker実行先ではDockerfile.simpleとcompose.simple.yamlを使う。DB専用コンテナやダッシュボードを立ち上げない。

```
docker compose -f compose.simple.yaml up -d --build
docker compose -f compose.simple.yaml logs --tail=50
```

この作業環境にはDockerがなく、イメージビルドは未検証。ブラウザが安定して公式サイトにつながる実行先は未確立。新規有料契約はしていない。

## 停止・再開

同じ環境設定・同じstateを使う。

```
python -m tdrbot.simple pause
python -m tdrbot.simple resume
python -m tdrbot.simple status
```

## 実データ検証

2026年11月14日、チャットのブラウザで両パーク当日の公演カードを表示して読み取り、その記録をレビュー専用の--preloaded-displayで単純版に渡した。公演回26件・公演マスタ12件をローカルSQLiteに保存。予報とアメダスを取得し、気象5件・予測5件・投稿文2件を保存。予測は根拠不足のため判定保留、投稿状態はdry_runでX送信0件。レビュー専用オプションはLIVE_POSTINGを強制falseにする。翌日の記録は与えていないため翌日ページの欠損ログも確認。

アメダス取得CLI単体も実通信成功。12:20観測の平均風速1.9m/s、北西、1時間雨量0mm、18.9℃、湿度47%を12:33に取得。これは動作確認時点の過去の値で、現在の値として再利用しない。

自動テスト140件通過。常時実行、候補サーバーからのブラウザ取得、X認証・初回実投稿は未確認。公演結果の全自動収集とモデル学習は後回し。全公演に無理に確率を生成しない。
