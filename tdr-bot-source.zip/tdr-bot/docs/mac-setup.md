# Mac無料運用の準備（v0.2）

公演情報の利用は依頼者が確認済み。設定に反映したので再確認は不要。

自宅Mac・SQLite・非商用Open-Meteoで進める。クラウド契約やDockerは不要。Xへの実投稿・課金は無効。雷・雨雲・WBGT・配信鮮度の不足は保留となる。必要データすべてを無料で確保できたという意味ではない。

## Macで行う作業

Python 3.12以降が必要。なければ https://www.python.org/downloads/macos/ の対応版を確認する。

ZIPを展開し、ターミナルで展開した `tdr-bot` に移動して実行：

```bash
python3 mac/install_mac.py
```

依存パッケージをネットから取得する。`mac/Install.command` も同梱するが、ダウンロードファイル保護や実行権限により開けない場合は上記を使う。保護の一括無効化は不要。

`~/Library/Application Support/TDRWeatherBot` に配置される。既存の `.env` とDBは上書きしない。設定ファイルは600、フォルダは700の権限にする。APIキーは会話や公開リポジトリに貼らない。`.env` はシェルコードとして実行せずデータとして読み込む。

`~/Library/LaunchAgents/jp.local.tdr-weather-bot.plist` に自動起動を登録する。**再起動後はユーザーがログインしてから**起動する。ログアウト中は稼働しない。自動ログインは設定しない。Mac実機での起動・再ログイン・通信・スリープの試験はまだ行っていない。

`caffeinate -i` でアイドルスリープを抑制する。手動スリープ、ふたを閉じた状態、停電、通信断は防がない。MacBookは電源接続し、通常はふたを開ける。

状態確認・投稿一時停止：

```bash
cd "$HOME/Library/Application Support/TDRWeatherBot"
.venv/bin/python -m tdrbot.worker status
.venv/bin/python -m tdrbot.worker pause
```

全体停止はインストーラーが表示する `launchctl bootout` コマンドを使う。設定を変えたら再起動する。

監視画面：

```bash
.venv/bin/python -m tdrbot.dashboard
```

http://127.0.0.1:8080/ を開く。Mac設定ではローカルのみに公開する。

## スマホで先に行えること

Botに使うXアカウントを決める。 https://developer.x.com/ で対象アカウントが正しいか確認する。外部ログイン・App作成・課金は本人の確認後に行う。画面の名称が変わる場合があるので、画面を見ながら進める。

Read/Write権限付きAppとユーザー認証が必要。API Key/Secret・Access Token/Secretが出た画面はスクリーンショットで送らない。クレジット購入は後回しでよい。初回投稿内容と料金の承認までは `LIVE_POSTING=false` のままにする。

Mac設定の仮上限は20件/日・10件/15分。通常投稿20件/日×30日×0.015米ドルなら9米ドル/月の計算例。課金承認済みではない。全公演を個別に前日・朝・直前投稿すると20件を超えるため、実投稿前に上限か集約形式を決める必要がある。

電気代・通信費は別。新しい有料サービスには契約していない。

無料データ接続の最新状況は `free-data-status.md` を参照。Macで `.venv/bin/python -m tdrbot.diagnose` により投稿なしの疎通確認ができます。
