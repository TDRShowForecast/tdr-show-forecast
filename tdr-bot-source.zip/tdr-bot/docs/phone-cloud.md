# スマホだけで設定・運用する構成 v0.4

## 方針

自宅Macは使わず、GitHub Actionsで約10分おきに1回実行し、Supabase PostgreSQLに履歴と投稿停止状態を保存する。スマホは設定・確認用。スマホを閉じてもクラウドの処理は続く。

本パッケージに構成とコードを追加した段階。GitHubリポジトリ作成、Supabaseプロジェクト作成、Secrets登録、本番デプロイはまだ行っていない。外部アカウントのログインやサービス契約もしていない。

## 利用料と実行精度

- GitHubの公開リポジトリで標準GitHub-hosted runnerを使うと実行部分は無料。ソースコードが公開されることを確認してから作成する。非公開ならアカウントの無料枠を消費するため、この頻度で無料運用できるとは保証しない。
- SupabaseはFreeを使用する。容量や利用枠を超えたら無料で継続できるとは限らない。自動で有料へ変更しない。
- X APIの投稿料は別。現在は投稿無効。クレジット購入や自動チャージは行わない。
- GitHubの定期実行は遅延・スキップの可能性があり、1分監視や公演30分前ちょうどの投稿を満たさない。公演前の処理は起動できた時点の最新データで評価する。
- 公開リポジトリは60日間リポジトリ活動がないと定期実行が停止される。通常のコード保守と稼働確認が必要。完全無人の長期保証はない。
- Supabase Freeも低活動が続くと一時停止する場合がある。動いているBotの通常の履歴保存はDB活動になるが、停止しないことを保証するものではない。

無料でまず運用を試すための構成。仕様書の厳密な定時投稿・完全無人の保証を満たす完成版ではない。

## 設定の流れ

1. GitHubアカウントを用意する。コードを置く新規リポジトリを作る（公開は本人の確認後）。ソース一式はリポジトリの直下に配置する。ZIPファイルを置くだけでは動かない。
2. SupabaseでFreeプロジェクトを作る。リージョンは近いものを選び、DBパスワードはパスワード管理アプリに保存する。
3. SupabaseのConnectからSession poolerを選ぶ。接続先は画面から正確にコピーし、5432ポートを使う。Transaction pooler（6543）はこのBotのセッションロックに対応しない。
4. 接続URLの先頭を `postgresql+psycopg://` とし、クエリに `sslmode=require` を設定する。パスワード中のURL予約文字はエンコードする。
5. GitHubリポジトリの Settings → Secrets and variables → Actions に、下表のSecretsを設定する。秘密値はコード・Issue・チャットに送らない。
6. Actions → TDR Forecast Bot → Run workflow → diagnoseを選ぶ。これはDB未設定でも実行でき、X投稿は行わない。
7. DATABASE_URL設定後、runを選び、DBに公演・予測・dry_runの履歴が残るか確認する。気象情報が不足する場合は保留になる。無料アダプターの実接続は前回タイムアウトしており、クラウドでも確認が必要。
8. 初回実投稿の承認と料金上限の確認が完了するまで、投稿用Variablesはfalseのままにする。

## GitHub Secrets

| 名前 | 内容 |
|---|---|
| DATABASE_URL | Supabase Session poolerの接続URL（TLS必須） |
| X_API_KEY | OAuth 1.0aのコンシューマーキー |
| X_API_SECRET | コンシューマーシークレット |
| X_ACCESS_TOKEN | 自分のBotアカウントのアクセストークン |
| X_ACCESS_SECRET | アクセストークンシークレット |
| ADMIN_WEBHOOK | 任意。本人が指定した管理者通知先のみ |

初回の接続診断だけならSecretsは不要。runにはDB接続が必要。Xの4つの秘密値は、投稿なしのデータ確認後に登録してもよい。

## GitHub Variables

| 名前 | 初期値 | 用途 |
|---|---|---|
| LIVE_POSTING | false | Xへの送信を無効化 |
| INITIAL_POST_APPROVED | false | 初回実投稿を未承認のままにする |

本番化はこの2つを有効化する操作だけでは完成しない。気象欠損、投稿案、料金、アカウント、派生データの出典表示、DB保持量の確認が先に必要。

## スマホからの管理

Actionsの手動実行で `pause` を選ぶと投稿を停止、`resume` で停止解除、`status` で状態確認。resumeだけで初回承認やLIVE_POSTINGのガードを解除することはない。

定期実行の停止はGitHubのワークフロー自体をDisableにする。定期実行を止めている間も、Secretsを公開しない。

DBは非公開の `tdr_bot` スキーマを作成し、通常のSupabase公開Data API対象に追加しない。ダッシュボードからTable Editor等で確認する。外部REST公開は不要。無料枠の容量を監視し、バックアップと履歴保持方針は運用前に決める。

## 確認済みと未確認

クラウド構成のローカルテストを追加。GitHub上での実ワークフロー、Supabase実接続、PostgreSQL実機ロック、X実投稿は未確認。公開ソースには秘密値や過去のキー画像を含めない。

## 一次資料

- https://docs.github.com/en/billing/concepts/product-billing/github-actions
- https://docs.github.com/en/actions/how-tos/manage-workflow-runs/disable-and-enable-workflows
- https://docs.github.com/en/actions/how-tos/troubleshoot-workflows
- https://supabase.com/docs/guides/database/connecting-to-postgres
- https://supabase.com/docs/guides/platform/free-project-pausing
