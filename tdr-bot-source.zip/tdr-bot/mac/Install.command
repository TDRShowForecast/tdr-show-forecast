#!/bin/zsh
cd -- "${0:A:h}/.." || exit 1
python3 mac/install_mac.py
result=$?
printf '\n終了コード: %s\nEnterで閉じます。' "$result"
read -r
exit "$result"
