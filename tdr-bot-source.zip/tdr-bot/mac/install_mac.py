#!/usr/bin/env python3
"""Install a per-user LaunchAgent. Run on the user's Mac, never as sudo."""
import os, plistlib, shutil, subprocess, sys
from pathlib import Path

def definition(target,python):
    return {
        'Label':'jp.local.tdr-weather-bot',
        'ProgramArguments':['/usr/bin/caffeinate','-i',str(python),'-m','tdrbot.worker','run'],
        'WorkingDirectory':str(target),
        'RunAtLoad':True,'KeepAlive':True,'ThrottleInterval':60,
        'StandardOutPath':str(target/'logs'/'worker.log'),
        'StandardErrorPath':str(target/'logs'/'error.log'),
        'EnvironmentVariables':{'PYTHONUNBUFFERED':'1'},
        'ProcessType':'Background'
    }

def main():
    if sys.platform!='darwin':raise SystemExit('このインストーラーはMac専用です。')
    if sys.version_info<(3,12):raise SystemExit('Python 3.12以降をインストールしてから実行してください。')
    if os.getuid()==0:raise SystemExit('sudoは使用せず、ログイン中のユーザーで実行してください。')
    source=Path(__file__).resolve().parents[1]
    target=Path.home()/'Library'/'Application Support'/'TDRWeatherBot'
    agent=Path.home()/'Library'/'LaunchAgents'/'jp.local.tdr-weather-bot.plist'
    domain=f'gui/{os.getuid()}'
    if agent.exists():subprocess.run(['launchctl','bootout',domain,str(agent)],check=False,capture_output=True)
    target.mkdir(parents=True,exist_ok=True);target.chmod(0o700)
    shutil.copytree(source,target,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.env','*.db','.venv','__pycache__','.pytest_cache','.git','logs'))
    (target/'logs').mkdir(exist_ok=True)
    env=target/'.env'
    if not env.exists():shutil.copyfile(target/'.env.mac.example',env)
    env.chmod(0o600)
    python=target/'.venv'/'bin'/'python'
    if not python.exists():subprocess.run([sys.executable,'-m','venv',str(target/'.venv')],check=True)
    subprocess.run([str(python),'-m','pip','install','-r',str(target/'requirements.txt')],check=True)
    agent.parent.mkdir(parents=True,exist_ok=True)
    with agent.open('wb') as f:plistlib.dump(definition(target,python),f)
    agent.chmod(0o600)
    subprocess.run(['launchctl','bootstrap',domain,str(agent)],check=True)
    print('インストール済み。初期設定ではX投稿は無効です。')
    print('設定ファイル:',env)
    print('停止: launchctl bootout '+domain+' '+str(agent))
    print('Macで実際の起動・気象取得を確認してください。')
if __name__=='__main__':main()
